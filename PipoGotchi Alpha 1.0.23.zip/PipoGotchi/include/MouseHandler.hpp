#pragma once
#include <windows.h>
#include "PetEngine.h"

class MouseHandler {
public:
    static void startDrag(PetEngine& pet, POINT mousePos);
    static void endDrag(PetEngine& pet);
    static void updateDrag(PetEngine& pet, POINT mousePos);
};