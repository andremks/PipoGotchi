// include/JumpPhysics.hpp
#pragma once
#include <windows.h>

struct JumpPhysics {
    float jumpPower = 0;
    float horizontalKick = 0;
    bool isJumping = false;
    DWORD jumpStartTime = 0;
    const float MAX_JUMP_HEIGHT = 10.0f;
    const float JUMP_DURATION = 400; // ms
};