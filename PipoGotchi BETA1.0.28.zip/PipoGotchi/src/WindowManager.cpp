#include "WindowManager.hpp"

#include <windows.h>

HWND WindowManager::createWindow(HINSTANCE hInstance, WNDPROC wndProc) {
    const wchar_t CLASS_NAME[] = L"PipoGotchiClass";

    WNDCLASS wc{};
    wc.lpfnWndProc = wndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;

    // Se já estiver registrada, RegisterClass falha; isso não é erro fatal aqui.
    RegisterClass(&wc);

    // Janela layered/topmost/toolwindow, sem borda.
    // O tamanho “real” do sprite é ajustado no renderer, mas aqui pode ser 42x42.
    return CreateWindowEx(
        WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        CLASS_NAME,
        L"PipoGotchi",
        WS_POPUP | WS_VISIBLE,
        100, 100, 42, 42,
        NULL, NULL, hInstance, NULL
    );
}

void WindowManager::setAlwaysOnTop(HWND hwnd) {
    SetWindowPos(
        hwnd,
        HWND_TOPMOST,
        0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE
    );
}
