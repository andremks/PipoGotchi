// src/PetPhysics.cpp
#include "PetPhysics.hpp"

#include "PetEngine.h"
#include <windows.h>

// Implementação da classe PetPhysics (sem namespace PetPhysics)

void PetPhysics::applyJump(PetEngine& pet, float power, float direction) {
    // Verifica se pode pular (no chão e não pulando já)
    if (pet.velY == 0.0f && !pet.jump.isJumping) {
        pet.velY = -power; // Negativo = para cima

        // Pequeno impulso lateral (mantém o efeito original)
        pet.x += (int)(direction * 10.0f);

        // Atualiza estado
        pet.currentState = PetState::JUMPING;
        pet.currentFrame = 0;
        pet.frameCounter = 0;

        pet.jump.isJumping = true;
        pet.jump.jumpStartTime = GetTickCount();
    }
}

void PetPhysics::applyGravity(PetEngine& pet, int groundY) {
    // Gravidade simples: se estiver acima do chão, cai; se atingir chão, zera.
    if (pet.y < groundY) {
        pet.velY += 0.8f;
        pet.y += (int)pet.velY;

        if (pet.y >= groundY) {
            pet.y = groundY;
            pet.velY = 0.0f;

            // Ao tocar no chão, termina pulo/queda
            if (pet.currentState == PetState::FALLING ||
                pet.currentState == PetState::FREE_FALL ||
                pet.currentState == PetState::JUMPING) {
                pet.currentState = PetState::IDLE;
                pet.currentFrame = 0;
                pet.frameCounter = 0;
            }

            pet.jump.isJumping = false;
        }
    } else {
        // Já está no chão
        pet.y = groundY;
        pet.velY = 0.0f;
        pet.jump.isJumping = false;
    }
}

bool PetPhysics::checkWindowCollision(int petX, int petY,
                                      const RECT& windowRect,
                                      const RECT& workArea) {
    // Checagem simples: retorna true se (petX,petY) estiver dentro da janela
    // e a janela estiver em área válida (pelo menos parcialmente no workArea).

    if (windowRect.right <= windowRect.left || windowRect.bottom <= windowRect.top)
        return false;

    bool windowInsideWorkArea =
        windowRect.right > workArea.left &&
        windowRect.left < workArea.right &&
        windowRect.bottom > workArea.top &&
        windowRect.top < workArea.bottom;

    if (!windowInsideWorkArea)
        return false;

    bool pointInside =
        petX >= windowRect.left &&
        petX <= windowRect.right &&
        petY >= windowRect.top &&
        petY <= windowRect.bottom;

    return pointInside;
}
