// src/OverlayRenderer.cpp

#include "OverlayRenderer.hpp"

#include <windows.h>
#include <gdiplus.h>

#include "PetEngine.h"

#include <cmath>

#pragma comment(lib, "gdiplus.lib")

using namespace Gdiplus;

// ================================
// CONTROLE DE ANIMAÇÃO DO Zzz
// ================================

static float zzzOffsetY = 0.0f;
static DWORD lastZzzTick = 0;
static int zzzFrame = 0; // 0 = "Zz", 1 = "Zzz"

// ================================
// CONTROLE DE ANIMAÇÃO DO PULO
// ================================

static DWORD lastJumpAnimTick = 0;
static float jumpSquashEffect = 0.0f; // Efeito de "agachamento" antes do pulo

static void TryLoadImage(Image*& slot, const wchar_t* path) {
    if (slot) { delete slot; slot = nullptr; }
    slot = new Image(path);
    if (!(slot && slot->GetLastStatus() == Ok)) {
        delete slot;
        slot = nullptr;
    }
}

static void TryLoadPngOrJpg(Image*& slot, const wchar_t* baseNoExt) {
    // tenta .png
    {
        wchar_t path[260];
        wsprintfW(path, L"%s.png", baseNoExt);
        TryLoadImage(slot, path);
        if (slot) return;
    }

    // fallback .jpg
    {
        wchar_t path[260];
        wsprintfW(path, L"%s.jpg", baseNoExt);
        TryLoadImage(slot, path);
        if (slot) return;
    }

    // fallback .jpeg (opcional)
    {
        wchar_t path[260];
        wsprintfW(path, L"%s.jpeg", baseNoExt);
        TryLoadImage(slot, path);
    }
}

OverlayRenderer::OverlayRenderer()
    : spriteWhite(nullptr),
      spriteBlue(nullptr),
      spriteGray(nullptr),
      foodApple(nullptr),
      foodBanana(nullptr),
      foodCookies(nullptr),
      foodPizza(nullptr),
      foodCarrot(nullptr),
      foodSushi(nullptr),
      soccerBall(nullptr),
      basketBall(nullptr) {
}

OverlayRenderer::~OverlayRenderer() {
    if (spriteWhite) delete spriteWhite;
    if (spriteBlue) delete spriteBlue;
    if (spriteGray) delete spriteGray;

    if (foodApple) delete foodApple;
    if (foodBanana) delete foodBanana;
    if (foodCookies) delete foodCookies;
    if (foodPizza) delete foodPizza;
    if (foodCarrot) delete foodCarrot;
    if (foodSushi) delete foodSushi;

    if (soccerBall) delete soccerBall;
    if (basketBall) delete basketBall;
}

bool OverlayRenderer::loadAssets() {
    // Sprites (tenta png e depois jpg)
    TryLoadPngOrJpg(spriteWhite, L"assets/sprite");
    bool okWhite = (spriteWhite && spriteWhite->GetLastStatus() == Ok);

    TryLoadPngOrJpg(spriteBlue, L"assets/spriteAzul");
    TryLoadPngOrJpg(spriteGray, L"assets/spriteCinza");

    // Foods (tenta png e depois jpg) - se algum não existir, só fica nullptr e cai no fallback emoji
    TryLoadPngOrJpg(foodApple, L"assets/apple");
    TryLoadPngOrJpg(foodBanana, L"assets/banana");
    TryLoadPngOrJpg(foodCookies, L"assets/cookies");
    TryLoadPngOrJpg(foodPizza, L"assets/pizza");
    TryLoadPngOrJpg(foodCarrot, L"assets/carrot");
    TryLoadPngOrJpg(foodSushi, L"assets/sushi");

    // Brincadeiras
    TryLoadPngOrJpg(soccerBall, L"assets/soccer-ball");
    TryLoadPngOrJpg(basketBall, L"assets/basketball");

    return okWhite;
}

void OverlayRenderer::renderPet(HWND hwnd, const PetEngine& pet) {
    Image* activeSheet = spriteWhite;
    if (pet.model == PetModel::Azul && spriteBlue) activeSheet = spriteBlue;
    if (pet.model == PetModel::Cinza && spriteGray) activeSheet = spriteGray;
    if (!activeSheet) return;

    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    BITMAPINFO bmi = {};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = 42;
    bmi.bmiHeader.biHeight = -42;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    HBITMAP hBitmap = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, &bits, NULL, 0);
    HGDIOBJ oldBmp = SelectObject(hdcMem, hBitmap);

    Graphics g(hdcMem);
    g.SetInterpolationMode(InterpolationModeNearestNeighbor);
    g.Clear(Color(0, 0, 0, 0));

    // ================================
    // FRAME REAL (COM OS NOVOS ESTADOS DE PULO)
    // ================================
    int frameReal = 0;
    float verticalOffset = 0.0f;
    float scaleY = 1.0f;

    // ================================
    // EFEITO DE RESPIRAÇÃO DURANTE O SONO
    // ================================
    float breathScaleY = 1.0f;
    float breathVerticalOffset = 0.0f;

    DWORD currentTime = GetTickCount();

    if (pet.currentState == PetState::SLEEP) {
        float breathWave = std::sin(pet.sleepBreathPhase);
        breathWave *= pet.sleepBreathIntensity;

        breathScaleY = 1.0f + (breathWave * 0.03f);
        breathVerticalOffset = breathWave * 0.5f;

        frameReal = 30;
    } else {
        switch (pet.currentState) {
        case PetState::IDLE:
            frameReal = pet.currentFrame % 2;
            break;

        case PetState::WALK:
            frameReal = 3 + (pet.currentFrame % 7);
            break;

        case PetState::JUMPING:
            frameReal = 17 + (pet.currentFrame % 4);
            if (pet.currentFrame < 2) {
                scaleY = 0.85f + (pet.currentFrame * 0.05f);
            } else {
                scaleY = 1.1f - ((pet.currentFrame - 2) * 0.05f);
            }
            verticalOffset = -std::sin(pet.currentFrame * 0.3f) * 2.0f;
            break;

        case PetState::FALLING:
            frameReal = 21 + (pet.currentFrame % 4);
            if (pet.currentFrame < 2) {
                scaleY = 1.0f + (pet.currentFrame * 0.03f);
            } else {
                scaleY = 0.9f + ((pet.currentFrame - 2) * 0.05f);
            }
            verticalOffset = pet.currentFrame * 0.5f;
            break;

        case PetState::FREE_FALL:
            frameReal = 21;
            scaleY = 1.0f + (pet.currentFrame * 0.02f);
            verticalOffset = pet.currentFrame * 1.0f;
            break;

        case PetState::SLEEP:
            frameReal = 30;
            break;

        default:
            frameReal = 0;
            break;
        }
    }

    int srcX = frameReal * 24;

    // Partículas de vento na queda rápida
    if (pet.currentState == PetState::FALLING && pet.velY > 5.0f) {
        SolidBrush windBrush(Color(80, 255, 255, 255));
        for (int i = 0; i < 3; i++) {
            float windX = 5.0f + (i * 8.0f);
            float windY = 20.0f + (i * 5.0f);
            float windSize = 3.0f + (i * 1.0f);

            if (pet.moveDirection == 1) {
                g.FillEllipse(&windBrush, -windX, windY, windSize, windSize);
            } else {
                g.FillEllipse(&windBrush, 42.0f + windX - windSize, windY, windSize, windSize);
            }
        }
    }

    // Efeito de antecipação (agachamento) antes do pulo
    if (pet.wasMouseInRange && pet.velY == 0 && !pet.jump.isJumping) {
        if (currentTime - lastJumpAnimTick > 100) {
            jumpSquashEffect = std::sin(currentTime * 0.02f) * 0.05f;
            lastJumpAnimTick = currentTime;
        }
        scaleY *= (1.0f - jumpSquashEffect);
    } else {
        jumpSquashEffect = 0.0f;
    }

    // ================================
    // SPRITE (COM ESPELHAMENTO E EFEITOS)
    // ================================
    GraphicsState spriteState = g.Save();

    float renderX = 0.0f;
    float renderY = verticalOffset + breathVerticalOffset;

    if (pet.currentState == PetState::SLEEP && breathScaleY != 1.0f) {
        float scaleCenterY = 42.0f / 2.0f;
        g.TranslateTransform(0, scaleCenterY);
        g.ScaleTransform(1.0f, breathScaleY);
        g.TranslateTransform(0, -scaleCenterY);
    }

    if (scaleY != 1.0f) {
        float scaleCenterY = 42.0f / 2.0f;
        g.TranslateTransform(0, scaleCenterY);
        g.ScaleTransform(1.0f, scaleY);
        g.TranslateTransform(0, -scaleCenterY);
    }

    if (pet.moveDirection == -1) {
        g.ScaleTransform(-1.0f, 1.0f);
        g.TranslateTransform(-42.0f, 0.0f);
    }

    g.DrawImage(
        activeSheet,
        Rect((int)renderX, (int)renderY, 42, 42),
        srcX, 0, 24, 24,
        UnitPixel
    );

    g.Restore(spriteState);

    // ================================
    // BRINCAR — JOGAR BOLA (SOCCER)
    // ================================
    if (pet.isPlayingBall && pet.ballUntil > pet.ballStart && soccerBall) {
        float duration = (float)(pet.ballUntil - pet.ballStart);
        float t = (float)(currentTime - pet.ballStart) / duration;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;

        // Ajuste fino (você já calibrou esses valores)
        float baseX = 14.0f;
        float baseY = 24.0f;
        const int ballSize = 12;

        float stepPhase = 0.0f;
        if (pet.currentState == PetState::WALK) {
            stepPhase = (float)(pet.currentFrame % 7) / 7.0f; // 0..1
        }

        float kick = std::sin(stepPhase * 6.28318f) * 1.2f;
        float bounce = std::fabs(std::sin((float)currentTime * 0.012f)) * 1.0f;
        float drift = (pet.moveDirection >= 0 ? 1.0f : -1.0f) * (t * 6.0f);

        float spins = 3.0f; // voltas
        float angle = 360.0f * (t * spins);

        int alpha = 255;
        if (t > 0.80f) {
            float ft = (t - 0.80f) / 0.20f;
            alpha = (int)(255.0f * (1.0f - ft));
            if (alpha < 0) alpha = 0;
        }

        GraphicsState ballState = g.Save();

        float cx = baseX + drift + kick + (ballSize / 2.0f);
        float cy = baseY + bounce + (ballSize / 2.0f);

        g.TranslateTransform(cx, cy);
        g.RotateTransform(angle);
        g.TranslateTransform(-cx, -cy);

        ImageAttributes ia;
        ColorMatrix cm = {
            1,0,0,0,0,
            0,1,0,0,0,
            0,0,1,0,0,
            0,0,0,(REAL)(alpha / 255.0f),0,
            0,0,0,0,1
        };
        ia.SetColorMatrix(&cm);

        Rect dest((int)(baseX + drift + kick), (int)(baseY + bounce), ballSize, ballSize);
        g.DrawImage(
            soccerBall,
            dest,
            0, 0,
            (INT)soccerBall->GetWidth(),
            (INT)soccerBall->GetHeight(),
            UnitPixel,
            &ia
        );

        g.Restore(ballState);
    }

    // ================================
    // BRINCAR — BASKETBALL (QUICAR VERTICAL)
    // ================================
    if (pet.isPlayingBasketball && pet.basketUntil > pet.basketStart && basketBall) {
        float duration = (float)(pet.basketUntil - pet.basketStart);
        float t = (float)(currentTime - pet.basketStart) / duration;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;

        // Pode reaproveitar os mesmos offsets que você calibrou no soccer
        float baseX = 14.0f;
        float baseY = 24.0f;
        const int ballSize = 12;

        // Amarra o "kick" ao passo do WALK (fica mais sincronizado)
        float stepPhase = 0.0f;
        if (pet.currentState == PetState::WALK) {
            stepPhase = (float)(pet.currentFrame % 7) / 7.0f; // 0..1
        }

        // Quicada mais forte (vertical)
        // Nota: usamos fabs(sin) para sempre "subir e descer" sem ir abaixo do chão.
        float bounce = std::fabs(std::sin(stepPhase * 6.28318f)) * 6.0f; // amplitude 6px

        // Pequeno "kick" horizontal só pra não ficar estático demais (bem sutil)
        float sway = std::sin(stepPhase * 6.28318f) * 0.6f;

        int alpha = 255;
        if (t > 0.85f) {
            float ft = (t - 0.85f) / 0.15f;
            alpha = (int)(255.0f * (1.0f - ft));
            if (alpha < 0) alpha = 0;
        }

        ImageAttributes ia;
        ColorMatrix cm = {
            1,0,0,0,0,
            0,1,0,0,0,
            0,0,1,0,0,
            0,0,0,(REAL)(alpha / 255.0f),0,
            0,0,0,0,1
        };
        ia.SetColorMatrix(&cm);

        // y sobe quando bounce aumenta, então usamos (baseY - bounce)
        Rect dest((int)(baseX + sway), (int)(baseY - bounce), ballSize, ballSize);
        g.DrawImage(
            basketBall,
            dest,
            0, 0,
            (INT)basketBall->GetWidth(),
            (INT)basketBall->GetHeight(),
            UnitPixel,
            &ia
        );
    }

    // ================================
    // COMER — tenta IMG (colorido), senão fallback emoji
    // ================================
    if (pet.isEating && !pet.eatingEmoji.empty()) {
        float duration = (float)((pet.eatingUntil > pet.eatingStart) ? (pet.eatingUntil - pet.eatingStart) : 1);
        float t = (float)(currentTime - pet.eatingStart) / duration;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;

        float jitterX = std::sin(currentTime * 0.055f) * 1.3f;
        float jitterY = std::cos(currentTime * 0.070f) * 1.0f;
        float scale = 1.6f - (t * 0.8f);

        int alpha = 255;
        if (alpha < 0) alpha = 0;
        if (alpha > 255) alpha = 255;

        float baseX = 16.0f;
        float baseY = 20.0f;

        Image* foodImg = nullptr;
        if (pet.eatingEmoji == L"🍎") foodImg = foodApple;
        else if (pet.eatingEmoji == L"🍌") foodImg = foodBanana;
        else if (pet.eatingEmoji == L"🍪") foodImg = foodCookies;
        else if (pet.eatingEmoji == L"🍕") foodImg = foodPizza;
        else if (pet.eatingEmoji == L"🥕") foodImg = foodCarrot;
        else if (pet.eatingEmoji == L"🍣") foodImg = foodSushi;

        if (foodImg) {
            GraphicsState eatState = g.Save();

            float centerX = baseX;
            float centerY = baseY;
            g.TranslateTransform(centerX, centerY);
            g.ScaleTransform(scale, scale);
            g.TranslateTransform(-centerX, -centerY);

            ImageAttributes ia;
            ColorMatrix cm2 = {
                1,0,0,0,0,
                0,1,0,0,0,
                0,0,1,0,0,
                0,0,0,(REAL)(alpha / 255.0f),0,
                0,0,0,0,1
            };
            ia.SetColorMatrix(&cm2);

            Rect dest((int)(baseX + jitterX), (int)(baseY + jitterY), 14, 14);
            g.DrawImage(
                foodImg,
                dest,
                0, 0,
                (INT)foodImg->GetWidth(),
                (INT)foodImg->GetHeight(),
                UnitPixel,
                &ia
            );

            g.Restore(eatState);
        } else {
            FontFamily ff(L"Segoe UI Emoji");
            Font foodFont(&ff, 16, FontStyleRegular, UnitPixel);

            SolidBrush shadow(Color((int)(alpha * 0.55f), 0, 0, 0));
            SolidBrush text(Color(alpha, 255, 255, 255));

            GraphicsState eatState = g.Save();

            float centerX = baseX;
            float centerY = baseY;
            g.TranslateTransform(centerX, centerY);
            g.ScaleTransform(scale, scale);
            g.TranslateTransform(-centerX, -centerY);

            g.DrawString(pet.eatingEmoji.c_str(), -1, &foodFont, PointF(baseX + 1.0f + jitterX, baseY + 1.0f + jitterY), &shadow);
            g.DrawString(pet.eatingEmoji.c_str(), -1, &foodFont, PointF(baseX + jitterX, baseY + jitterY), &text);

            g.Restore(eatState);
        }
    }

    // ================================
    // ANIMAÇÃO DO Zzz...
    // ================================
    if (pet.currentState == PetState::SLEEP) {
        DWORD now = GetTickCount();

        if (now - lastZzzTick > 40) {
            lastZzzTick = now;
            zzzOffsetY -= 0.3f;
            if (zzzOffsetY < -6.0f) zzzOffsetY = 0.0f;

            if (now % 800 < 400) zzzFrame = 0;
            else zzzFrame = 1;

            const wchar_t* zzzText = (zzzFrame == 0) ? L"zZz.." : L"ZzZ..";

            FontFamily fontFamily(L"Arial");
            Font font(&fontFamily, 10, FontStyleBold, UnitPixel);

            float zzzYOffset = 3.0f + zzzOffsetY + (breathVerticalOffset * 2.0f);

            SolidBrush shadow(Color(120, 0, 0, 0));
            g.DrawString(zzzText, -1, &font, PointF(7.0f, 4.0f + zzzYOffset), &shadow);

            SolidBrush text(Color(220, 255, 255, 255));
            g.DrawString(zzzText, -1, &font, PointF(6.0f, 3.0f + zzzYOffset), &text);
        }
    } else {
        zzzOffsetY = 0.0f;
    }

    // ================================
    // CARINHO (♥)
    // ================================
    if (pet.isPetting) {
        FontFamily fontFamily(L"Arial");
        Font font(&fontFamily, 12, FontStyleBold, UnitPixel);

        SolidBrush shadow(Color(140, 0, 0, 0));
        SolidBrush text(Color(240, 255, 105, 180));

        g.DrawString(L"♥", -1, &font, PointF(27.0f, 4.0f), &shadow);
        g.DrawString(L"♥", -1, &font, PointF(26.0f, 3.0f), &text);
    }

    // ================================
    // CORAÇÕES (PARTÍCULAS DO CARINHO) + FADE NO TOPO
    // ================================
    if (!pet.hearts.empty()) {
        FontFamily ff(L"Arial");
        Font heartFont(&ff, 12, FontStyleBold, UnitPixel);

        const float FADE_START_Y = -5.0f; // totalmente transparente
        const float FADE_END_Y = 0.0f;    // totalmente visível

        for (const auto& p : pet.hearts) {
            float hx = p.x;
            float hy = p.y;

            float tt = 1.0f;
            if (hy <= FADE_START_Y) tt = 0.0f;
            else if (hy < FADE_END_Y) tt = (hy - FADE_START_Y) / (FADE_END_Y - FADE_START_Y);

            int aHeart = (int)(230.0f * tt);
            int aShadow = (int)(120.0f * tt);

            if (aHeart < 0) aHeart = 0;
            if (aHeart > 230) aHeart = 230;
            if (aShadow < 0) aShadow = 0;
            if (aShadow > 120) aShadow = 120;

            SolidBrush heartBrush(Color(aHeart, 255, 80, 140));
            SolidBrush heartShadow(Color(aShadow, 0, 0, 0));

            const wchar_t* heart = L"♥";
            g.DrawString(heart, -1, &heartFont, PointF(hx + 1.0f, hy + 1.0f), &heartShadow);
            g.DrawString(heart, -1, &heartFont, PointF(hx, hy), &heartBrush);
        }
    }

    // ================================
    // UPDATE LAYERED WINDOW
    // ================================
    POINT ptSrc = { 0, 0 };
    POINT ptDst = { pet.x, pet.y };
    SIZE size = { 42, 42 };

    BLENDFUNCTION bf = {};
    bf.BlendOp = AC_SRC_OVER;
    bf.SourceConstantAlpha = 255;
    bf.AlphaFormat = AC_SRC_ALPHA;

    UpdateLayeredWindow(
        hwnd,
        hdcScreen,
        &ptDst,
        &size,
        hdcMem,
        &ptSrc,
        0,
        &bf,
        ULW_ALPHA
    );

    // ================================
    // LIMPEZA
    // ================================
    SelectObject(hdcMem, oldBmp);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}
