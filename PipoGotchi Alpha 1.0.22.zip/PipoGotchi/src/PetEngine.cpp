// src/PetEngine.cpp

#include "PetEngine.h"
#include "SystemCore.h"

#include <algorithm>
#include <cmath>
#include <windows.h>

// =====================================================
// FUNÇÕES AUXILIARES PARA PULO
// =====================================================

float PetEngine::calculateJumpPower(int distX, int distY) {
    // Distância euclidiana do cursor
    float distance = std::sqrt((float)(distX * distX + distY * distY));

    // Normalizar para 0-1 (cursor mais longe = pulo mais alto)
    float normalized = distance / 120.0f;

    // Limitar entre 0.3 e 1.0
    if (normalized < 0.3f) normalized = 0.3f;
    if (normalized > 1.0f) normalized = 1.0f;

    // Calcular altura máxima para este pulo
    float jumpHeight = normalized * jump.MAX_JUMP_HEIGHT;

    // Limitar altura máxima absoluta
    if (jumpHeight > MAX_JUMP_HEIGHT) jumpHeight = MAX_JUMP_HEIGHT;

    return jumpHeight;
}

void PetEngine::triggerJump(int distX, int distY) {
    DWORD now = GetTickCount();

    // Cooldown para evitar spam
    if (now - lastJumpTime < (DWORD)JUMP_COOLDOWN) return;

    // Só pula se estiver no chão
    if (velY != 0) return;

    jump.jumpPower = calculateJumpPower(distX, distY);

    // Dar um pequeno empurrão horizontal (oposto ao cursor)
    jump.horizontalKick = (distX > 0) ? -2.0f : 2.0f;

    jump.isJumping = true;
    jump.jumpStartTime = now;
    velY = -jump.jumpPower * 0.1f;

    // Mudar estado
    if (currentState != PetState::SLEEP) currentState = PetState::JUMPING;

    currentFrame = 0;
    frameCounter = 0;

    lastJumpTime = now;
}

// =====================================================
// FUNÇÃO PRINCIPAL UPDATE
// =====================================================

void PetEngine::Update(RECT workArea, POINT mousePos, RECT activeWindowRect, bool isWindowValid) {
    // =====================================================
    // PASSO 1 — DETECTAR MOVIMENTO DO MOUSE
    // =====================================================
    DWORD currentTime = GetTickCount();
    const int RENDERW = 40;

    // ---- COMER: detectar fim e soltar corações (felicidade)
    static bool wasEatingLastFrame = false;
    bool isEatingNow = isEating;
    if (wasEatingLastFrame && !isEatingNow) {
        SpawnHearts(8); // ajuste a quantidade (6~12 fica bom)
    }
    wasEatingLastFrame = isEatingNow;

    // --- TRAVAR EM IDLE ENQUANTO COME ---
    if (isEating) {
        currentState = PetState::IDLE;
        jump.isJumping = false; // opcional: evita trocar pra JUMPING/FALLING por lógica do comportamento
        speed = 0.0f;           // opcional: impede WALK por qualquer resto de lógica
        // não retornar aqui: deixa física/gravidade/drag continuarem funcionando
    }

    // =====================================================
    // COMER — EXPIRAR TIMER (emoji)
    // =====================================================
    if (isEating && currentTime >= eatingUntil) {
        isEating = false;
        eatingEmoji.clear();
    }

    // =====================================================
    // BRINCAR — JOGAR BOLA (soccer)
    // =====================================================
    if (isPlayingBall && currentTime >= ballUntil) {
        isPlayingBall = false;
    }

    if (isPlayingBall) {
        lastMouseMoveTime = currentTime; // impede entrar em SLEEP

        // não briga com o usuário arrastando: se estiver arrastando, só "pausa" a imposição de WALK
        if (!isDragging) {
            currentState = PetState::WALK;
            moveDirection = (ballDirection == 0) ? 1 : ballDirection;
            speed = 3.0f;
        }
    }

    // =====================================================
    // BRINCAR — BASKETBALL (quicar)
    // =====================================================
    if (isPlayingBasketball && currentTime >= basketUntil) {
        isPlayingBasketball = false;
    }

    if (isPlayingBasketball) {
        lastMouseMoveTime = currentTime; // impede entrar em SLEEP

        if (!isDragging) {
            currentState = PetState::WALK;
            moveDirection = (basketDirection == 0) ? 1 : basketDirection;
            speed = 3.0f;
        }
    }

    // =====================================================
    // CARINHO — EXPIRAR TIMER + PARTÍCULAS
    // =====================================================
    if (isPetting && currentTime >= pettingUntil) {
        isPetting = false;
    }

    // Spawn contínuo enquanto estiver em carinho
    static DWORD lastHeartSpawn = 0;
    if (isPetting) {
        if (currentTime - lastHeartSpawn > 220) {
            SpawnHearts(2);
            lastHeartSpawn = currentTime;
        }
    }

    // Atualizar partículas (movimento + remover expiradas)
    for (size_t i = 0; i < hearts.size();) {
        HeartParticle& p = hearts[i];

        // remove por tempo de vida
        if (currentTime - p.born >= p.life) {
            hearts[i] = hearts.back();
            hearts.pop_back();
            continue;
        }

        // movimento simples (por frame, aproximado ao timer)
        p.x += p.vx;
        p.y += p.vy;

        // leve desaceleração e drift
        p.vx *= 0.98f;
        p.vy *= 0.995f;

        ++i;
    }

    if (mousePos.x != lastMousePos.x || mousePos.y != lastMousePos.y) {
        lastMousePos = mousePos;
        lastMouseMoveTime = currentTime;

        // Acorda se estiver dormindo
        if (currentState == PetState::SLEEP) {
            currentState = PetState::IDLE;
            currentFrame = 2;
            frameCounter = 0;

            sleepBreathPhase = 0.0f; // Resetar respiração
            sleepBreathIntensity = 0.0f;
        }
    }

    // =====================================================
    // PASSO 2 — ENTRAR EM MODO DORMIR (PERMITIR EM JANELAS)
    // =====================================================
    const DWORD SLEEP_DELAY = 16000; // 16 segundos

    bool canSleep =
        !isDragging &&
        velY == 0 &&
        currentState != PetState::FALLING &&
        currentState != PetState::FREE_FALL &&
        !jump.isJumping;

    // Durante brincadeiras, não deixa entrar em sleep
    if (isPlayingBall || isPlayingBasketball) {
        canSleep = false;
    }

    if (canSleep && (currentTime - lastMouseMoveTime > SLEEP_DELAY)) {
        if (currentState != PetState::SLEEP) {
            currentState = PetState::SLEEP;
            currentFrame = 2;
            frameCounter = 0;

            sleepBreathPhase = 0.0f; // Iniciar respiração
            sleepBreathIntensity = 0.0f;
            lastBreathUpdate = currentTime;
        }
    }

    // =====================================================
    // PASSO 3 — ATUALIZAR ANIMAÇÃO DE RESPIRAÇÃO (MAS CONTINUAR FÍSICA)
    // =====================================================
    if (currentState == PetState::SLEEP) {
        if (currentTime - lastBreathUpdate > 50) {
            lastBreathUpdate = currentTime;

            if (sleepBreathIntensity < 1.0f) {
                sleepBreathIntensity += 0.05f;
            }
            if (sleepBreathIntensity > 1.0f) sleepBreathIntensity = 1.0f;

            sleepBreathPhase += 0.08f;
            if (sleepBreathPhase > 6.28318f) sleepBreathPhase -= 6.28318f; // 2π
        }
    } else {
        sleepBreathPhase = 0.0f;
        sleepBreathIntensity = 0.0f;
    }

    const int RENDER_W = 40;

    // =====================================================
    // 1. MODO ARRASTAR
    // =====================================================
    if (isDragging) {
        x = mousePos.x - dragOffset.x;
        y = mousePos.y - dragOffset.y;
        velY = 0;
        return;
    }

    // =====================================================
    // 2. COMPORTAMENTO E DETECÇÃO DE PULO (NÃO APLICAR SE DORMINDO)
    // =====================================================
    if (currentState != PetState::SLEEP) {
        // Se estiver em brincadeira, não deixa o comportamento do mouse sobrescrever o WALK
        bool ignoreMouseAI = (isPlayingBall || isPlayingBasketball);

        int distX = mousePos.x - (x + (RENDER_W / 2));
        int distY = mousePos.y - (y + (RENDER_W / 2));
        float distanceToCursor = std::sqrt((float)(distX * distX + distY * distY));
        bool mousePerto = (distanceToCursor <= 120);

        bool cursorEntrouAgora = false;
        if (mousePerto && !wasMouseInRange) cursorEntrouAgora = true;

        if (!ignoreMouseAI) {
            if (mousePerto) wasMouseInRange = true;
            else wasMouseInRange = false;
        } else {
            wasMouseInRange = false;
        }

        PetState estadoAnterior = currentState;

        if (!ignoreMouseAI) {
            if (mousePerto) {
                if (cursorEntrouAgora && !isDragging) {
                    DWORD jumpTime = GetTickCount();

                    if (!isDragging && velY == 0 &&
                        currentState != PetState::SLEEP &&
                        (jumpTime - lastJumpTime) > (DWORD)JUMP_COOLDOWN) {

                        float normalizedDistance = distanceToCursor / 120.0f;
                        if (normalizedDistance < 0.3f) normalizedDistance = 0.3f;
                        if (normalizedDistance > 1.0f) normalizedDistance = 1.0f;

                        jump.jumpPower = normalizedDistance * jump.MAX_JUMP_HEIGHT;
                        jump.horizontalKick = (distX > 0) ? -1.5f : 1.5f;

                        if (distY < -30) {
                            jump.jumpPower *= 1.2f;
                        }

                        jump.isJumping = true;
                        jump.jumpStartTime = jumpTime;
                        velY = -jump.jumpPower * 0.15f;

                        currentState = PetState::JUMPING;
                        currentFrame = 0;
                        frameCounter = 0;

                        lastJumpTime = jumpTime;
                        behaviorTimer = 0;
                    }
                }

                if (!jump.isJumping) {
                    if (abs(distX) > 15 && velY == 0) {
                        currentState = PetState::WALK;
                        moveDirection = (distX > 0) ? 1 : -1;
                        speed = 3.5f + (abs(distX) / 120.0f) * 1.0f;
                    } else {
                        currentState = PetState::IDLE;
                        if (abs(distX) > 5) {
                            moveDirection = (distX > 0) ? 1 : -1;
                        }
                    }
                }
            } else {
                wasMouseInRange = false;
                behaviorTimer++;

                if (behaviorTimer > 120 && !jump.isJumping) {
                    behaviorTimer = 0;

                    if (rand() % 100 < 60) {
                        currentState = PetState::IDLE;
                    } else {
                        currentState = PetState::WALK;
                        moveDirection = (rand() % 3 == 0) ? -moveDirection : moveDirection;
                        speed = 2.0f + (rand() % 100) / 100.0f;
                    }

                    if (currentState != estadoAnterior && !jump.isJumping) {
                        currentFrame = 0;
                        frameCounter = 0;
                    }
                }
            }
        }

        if (jump.isJumping) {
            DWORD now = GetTickCount();
            float elapsed = (float)(now - jump.jumpStartTime);

            if (elapsed < jump.JUMP_DURATION * 0.4f) {
                x += (int)jump.horizontalKick;
                currentState = PetState::JUMPING;
            } else if (elapsed < jump.JUMP_DURATION * 0.6f) {
                if (currentState == PetState::JUMPING) {
                    currentState = PetState::FALLING;
                    currentFrame = 0;
                    frameCounter = 0;
                }
            } else {
                jump.horizontalKick *= 0.95f;
                if (velY > TERMINAL_VELOCITY * 0.8f) {
                    jump.isJumping = false;
                }
            }
        }
    }

    // =====================================================
    // 3. FÍSICA E CHÃO (SEMPRE EXECUTAR, MESMO DORMINDO)
    // =====================================================

    int screenBottom = GetSystemMetrics(SM_CYSCREEN);
    int groundY;

    if (SystemCore::IsFullscreenActive()) {
        groundY = screenBottom - RENDER_W + 4;
    } else {
        groundY = workArea.bottom - RENDER_W + 4;
    }

    static bool wasOnWindowLastFrame = false;
    bool windowJustDisappeared = wasOnWindowLastFrame && !isWindowValid;
    wasOnWindowLastFrame = isOnWindow;
    isOnWindow = false;

    if (isWindowValid) {
        int petRight = x + RENDER_W;
        int petBottom = y + RENDER_W;

        bool overlapX = petRight > activeWindowRect.left && x < activeWindowRect.right;
        bool closeBelow = petBottom >= activeWindowRect.top && petBottom <= activeWindowRect.top + 40;

        int windowGroundY = activeWindowRect.top - (RENDER_W - 4);

        if (overlapX && closeBelow && windowGroundY < groundY) {
            groundY = windowGroundY;
            isOnWindow = true;
        }
    }

    if (windowJustDisappeared && y < workArea.bottom - RENDER_W + 4) {
        if (currentState == PetState::SLEEP) {
            currentState = PetState::FREE_FALL;
            currentFrame = 0;
            frameCounter = 0;

            sleepBreathPhase = 0.0f;
            sleepBreathIntensity = 0.0f;

            if (velY == 0) velY = 4.0f;
        } else if (velY == 0 && !jump.isJumping) {
            currentState = PetState::FREE_FALL;
            currentFrame = 0;
            frameCounter = 0;
            velY = 4.0f;
        }

        groundY = workArea.bottom - RENDER_W + 4;
        isOnWindow = false;
    }

    if (y < groundY || jump.isJumping || (currentState == PetState::FREE_FALL)) {
        velY += GRAVITY;
        if (velY > TERMINAL_VELOCITY) velY = TERMINAL_VELOCITY;

        y += (int)velY;

        if (y >= groundY) {
            y = groundY;
            velY = 0;

            if (currentState == PetState::FREE_FALL || currentState == PetState::FALLING) {
                currentState = PetState::IDLE;
                currentFrame = 0;
                frameCounter = 0;
            }

            jump.isJumping = false;
        }
    } else if (y > groundY) {
        y = groundY;
        velY = 0;
    } else {
        velY = 0;
    }

    // 3.4 — Movimentação Lateral (Caminhar) - NÃO APLICAR SE DORMINDO
    if (currentState == PetState::WALK && velY == 0 && currentState != PetState::SLEEP) {
        x += (int)(moveDirection * speed);

        const int WRAP_MARGIN = 14;
        const int leftEdge = workArea.left;
        const int rightEdge = workArea.right;

        if (x > rightEdge + WRAP_MARGIN) {
            x = leftEdge - RENDERW - WRAP_MARGIN;
        } else if (x + RENDERW < leftEdge - WRAP_MARGIN) {
            x = rightEdge + WRAP_MARGIN;
        }
    }

    // =====================================================
    // DETECTAR QUEDA LIVRE (INCLUINDO QUEDA DE JANELA)
    // =====================================================
    bool fellFromWindow = windowJustDisappeared && y < workArea.bottom - RENDER_W + 4;
    if (fellFromWindow || (velY > TERMINAL_VELOCITY * 0.7f && !isOnWindow && !jump.isJumping)) {
        if (currentState != PetState::FREE_FALL) {
            currentState = PetState::FREE_FALL;
            currentFrame = 0;
            frameCounter = 0;
        }
    } else if (currentState == PetState::FREE_FALL && velY < TERMINAL_VELOCITY * 0.3f) {
        currentState = PetState::IDLE;
        currentFrame = 0;
        frameCounter = 0;
    }

    // =====================================================
    // 4. ANIMAÇÃO (SÓ APLICAR SE NÃO ESTIVER DORMINDO)
    // =====================================================
    if (currentState != PetState::SLEEP) {
        frameCounter++;

        int framesCount = 0;
        int animSpeed = 0;

        if (currentState == PetState::IDLE) {
            framesCount = 2;
            animSpeed = 12;
            currentFrame = std::min(currentFrame, 1);
        } else if (currentState == PetState::WALK) {
            framesCount = 7;
            animSpeed = 2;
            currentFrame = std::min(currentFrame, 6);
        } else if (currentState == PetState::JUMPING) {
            framesCount = 4;
            animSpeed = 6;
            currentFrame = std::min(currentFrame, 3);
        } else if (currentState == PetState::FALLING) {
            framesCount = 4;
            animSpeed = 8;
            currentFrame = std::min(currentFrame, 3);
        } else if (currentState == PetState::FREE_FALL) {
            framesCount = 4;
            animSpeed = 6;
            currentFrame = std::min(currentFrame, 3);
        }

        if (animSpeed > 0 && frameCounter >= animSpeed) {
            frameCounter = 0;
            currentFrame = (currentFrame + 1) % framesCount;
        }
    } else {
        currentFrame = 2;
        frameCounter = 0;
    }
}
