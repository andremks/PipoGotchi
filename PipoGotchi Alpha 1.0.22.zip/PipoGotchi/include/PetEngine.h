// include/PetEngine.h

#ifndef PETENGINE_H
#define PETENGINE_H

// Windows types (HWND, RECT, POINT, DWORD, GetTickCount)
#include <windows.h>

// std::vector, std::wstring
#include <vector>
#include <string>

// rand()
#include <cstdlib>

#include "PetState.hpp"

enum class PetModel {
    Branco = 0,
    Azul = 1,
    Cinza = 2
};

struct JumpPhysics {
    float jumpPower = 0;
    float horizontalKick = 0;
    bool isJumping = false;
    DWORD jumpStartTime = 0;
    const float MAX_JUMP_HEIGHT = 80.0f;
    const float JUMP_DURATION = 400; // ms
};

// Partículas de coração (para o carinho)
struct HeartParticle {
    float x = 0.0f; // posição relativa ao pet (pixels)
    float y = 0.0f;
    float vx = 0.0f; // velocidade (px por frame, aprox)
    float vy = 0.0f;
    DWORD born = 0; // GetTickCount()
    DWORD life = 900; // ms
};

class PetEngine {
public:
    PetModel model = PetModel::Branco;

    int x = 100, y = 100;
    float speed = 2.0f;
    float velY = 0;
    int moveDirection = 1;

    PetState currentState = PetState::IDLE;

    int currentFrame = 0;
    int frameCounter = 0;

    bool isOnWindow = false;
    int behaviorTimer = 0;

    bool isDragging = false;
    POINT dragOffset = { 0, 0 };

    DWORD lastMouseMoveTime = 0;
    POINT lastMousePos = { 0, 0 };

    JumpPhysics jump;
    bool wasMouseInRange = false;
    DWORD lastJumpTime = 0;

    // =========================
    // Carinho
    // =========================
    bool isPetting = false;
    DWORD pettingUntil = 0;

    // Partículas (corações)
    std::vector<HeartParticle> hearts;

    void SpawnHearts(int count = 8) {
        DWORD now = GetTickCount();

        for (int i = 0; i < count; i++) {
            HeartParticle p;

            // Nascer perto do topo/direita do pet (ajuste livre)
            p.x = 18.0f + (float)((rand() % 14) - 7); // 11..25
            p.y = 10.0f + (float)((rand() % 10) - 5); // 5..15
            p.vx = ((rand() % 100) / 100.0f - 0.5f) * 0.6f; // -0.3..0.3
            p.vy = -1.2f - (rand() % 100) / 100.0f * 0.8f;  // -1.2..-2.0
            p.born = now;
            p.life = 650 + (rand() % 450); // 650..1100ms

            hearts.push_back(p);
        }
    }

    void StartPetting(DWORD durationMs = 2000) {
        isPetting = true;
        pettingUntil = GetTickCount() + durationMs;

        // Estouro inicial de corações
        SpawnHearts(10);
    }

    // =========================
    // Comer (emoji)
    // =========================
    bool isEating = false;
    DWORD eatingStart = 0;
    DWORD eatingUntil = 0;

    // O mesmo emoji escolhido no menu.
    // (wstring para guardar UTF-16 e desenhar com GDI+ DrawString)
    std::wstring eatingEmoji;

    void StartEating(const wchar_t* emoji, DWORD durationMs = 1400) {
        isEating = true;
        eatingStart = GetTickCount();
        eatingUntil = eatingStart + durationMs;
        eatingEmoji = (emoji ? emoji : L"");
    }

    // =========================
    // Brincar — Jogar bola (soccer)
    // =========================
    bool isPlayingBall = false;
    DWORD ballStart = 0;
    DWORD ballUntil = 0;

    // Congela uma direção durante a brincadeira, para ficar “natural”
    int ballDirection = 1;

    void StartPlayingBall(DWORD durationMs = 3200) {
        DWORD now = GetTickCount();

        isPlayingBall = true;
        ballStart = now;
        ballUntil = now + durationMs;

        // Evita conflito visual com “comer”
        isEating = false;
        eatingEmoji.clear();

        // Evita dormir durante a brincadeira
        lastMouseMoveTime = now;

        // Fixa uma direção (mantém a atual)
        ballDirection = (moveDirection == 0) ? 1 : moveDirection;

        // Força a animação começar certinha
        currentState = PetState::WALK;
        currentFrame = 0;
        frameCounter = 0;
    }

    // =========================
    // Brincar — Basketball (quicar)
    // =========================
    bool isPlayingBasketball = false;
    DWORD basketStart = 0;
    DWORD basketUntil = 0;

    // Congela uma direção durante a brincadeira (igual soccer)
    int basketDirection = 1;

    void StartPlayingBasketball(DWORD durationMs = 3200) {
        DWORD now = GetTickCount();

        isPlayingBasketball = true;
        basketStart = now;
        basketUntil = now + durationMs;

        // Evita conflito visual com “comer”
        isEating = false;
        eatingEmoji.clear();

        // Evita dormir durante a brincadeira
        lastMouseMoveTime = now;

        // Fixa uma direção (mantém a atual)
        basketDirection = (moveDirection == 0) ? 1 : moveDirection;

        // Força a animação começar certinha
        currentState = PetState::WALK;
        currentFrame = 0;
        frameCounter = 0;
    }

    // CONSTANTES DE FÍSICA
    const int JUMP_COOLDOWN = 800;
    const float GRAVITY = 2.5f;
    const float MAX_JUMP_HEIGHT = 30.0f;
    const float TERMINAL_VELOCITY = 12.0f;

    float calculateJumpPower(int distX, int distY);
    void triggerJump(int distX, int distY);

    // Sono / respiração
    float sleepBreathPhase = 0.0f;
    float sleepBreathIntensity = 0.0f;
    DWORD lastBreathUpdate = 0;

    void Update(RECT workArea, POINT mousePos, RECT activeWindowRect, bool isWindowValid);
};

#endif // PETENGINE_H
