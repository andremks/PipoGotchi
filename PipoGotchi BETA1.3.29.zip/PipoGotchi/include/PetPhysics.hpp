#pragma once
#include <windows.h>

class PetEngine;

class PetPhysics {
public:
    static void applyGravity(PetEngine& pet, int groundY);  // Mudei a assinatura
    static bool checkWindowCollision(int petX, int petY, 
                                     const RECT& windowRect, 
                                     const RECT& workArea);
    
    // Nova função para pulo
    static void applyJump(PetEngine& pet, float power, float direction);
};