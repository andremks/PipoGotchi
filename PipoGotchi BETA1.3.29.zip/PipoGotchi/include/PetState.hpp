// include/PetState.hpp
#pragma once
#include <windows.h>

enum class PetState
{
    IDLE,
    WALK,
    FALL,
    CLIMB,
    SIT,
    SLEEP,
    JUMPING,
    FALLING,
    FREE_FALL
};

struct PetBehavior {
    int timer = 0;
    int direction = 1;
    bool isNearMouse = false;
    
    void updateBehavior(POINT mousePos, int petX, int petY);
    PetState determineState();
};