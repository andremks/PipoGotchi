#ifndef SYSTEM_CORE_H
#define SYSTEM_CORE_H

#include <windows.h>

class SystemCore {
public:
    static HWND CreatePetWindow(HINSTANCE hInstance, WNDPROC wndProc);

    // Compat: área útil do "sistema" (normalmente primário).
    static RECT GetWorkArea();

    // Área útil (rcWork) do monitor mais próximo do ponto.
    static RECT GetWorkAreaFromPoint(POINT pt);

    // NOVO: retorna rcWork e rcMonitor do monitor mais próximo do ponto.
    // rcWork = área útil (sem taskbar), rcMonitor = área total do monitor.
    static bool GetMonitorRectsFromPoint(POINT pt, RECT& outWorkArea, RECT& outMonitorArea);

    // NOVO: fullscreen por monitor (não só no primário).
    static bool IsFullscreenActiveOnMonitor(HMONITOR mon);

    // Compat: mantém para usos antigos.
    static bool IsFullscreenActive();
};

#endif
