#include "SystemCore.h"
#include <windows.h>

HWND SystemCore::CreatePetWindow(HINSTANCE hInstance, WNDPROC wndProc)
{
    const wchar_t CLASS_NAME[] = L"PipoGotchiClass";

    WNDCLASS wc = {};
    wc.style = CS_DBLCLKS; // Necessário para WM_LBUTTONDBLCLK [web:192]
    wc.lpfnWndProc = wndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;

    RegisterClass(&wc);

    return CreateWindowEx(
        WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        CLASS_NAME, L"PipoGotchi",
        WS_POPUP | WS_VISIBLE,
        100, 100, 32, 32,
        NULL, NULL, hInstance, NULL
    );
}

RECT SystemCore::GetWorkArea()
{
    RECT workArea;
    SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);

    // Verifica se a Taskbar está oculta (F11/Jogos), então o "chão" vira o limite do monitor.
    HWND hTaskbar = FindWindow(L"Shell_TrayWnd", NULL);
    if (hTaskbar) {
        if (!IsWindowVisible(hTaskbar)) {
            workArea.bottom = GetSystemMetrics(SM_CYSCREEN);
            workArea.right = GetSystemMetrics(SM_CXSCREEN);
        }
    }

    return workArea;
}

RECT SystemCore::GetWorkAreaFromPoint(POINT pt) {
    HMONITOR mon = MonitorFromPoint(pt, MONITOR_DEFAULTTONEAREST);

    MONITORINFO mi{};
    mi.cbSize = sizeof(MONITORINFO);

    if (GetMonitorInfo(mon, &mi)) {
        return mi.rcWork; // área útil do monitor (desconta taskbar daquele monitor)
    }

    // fallback (se der algo muito errado)
    return SystemCore::GetWorkArea();
}


bool SystemCore::IsFullscreenActive()
{
    HWND hwnd = GetForegroundWindow();
    if (!hwnd) return false;

    RECT windowRect;
    GetWindowRect(hwnd, &windowRect);

    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    return (windowRect.left <= 0 && windowRect.top <= 0 &&
            windowRect.right >= screenWidth && windowRect.bottom >= screenHeight);
}
