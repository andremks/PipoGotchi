#ifndef SYSTEM_CORE_H
#define SYSTEM_CORE_H

#include <windows.h>

class SystemCore {
public:
    static HWND CreatePetWindow(HINSTANCE hInstance, WNDPROC wndProc);
    static RECT GetWorkArea();
    static RECT GetWorkAreaFromPoint(POINT pt);
    static bool IsFullscreenActive(); // Apenas uma declaração aqui
};

#endif