// include/OverlayRenderer.hpp

#pragma once

#include <windows.h>

namespace Gdiplus {
class Image;
}

class PetEngine;

class OverlayRenderer {
private:
    Gdiplus::Image* spriteWhite;
    Gdiplus::Image* spriteBlue;
    Gdiplus::Image* spriteGray;

    // Foods
    Gdiplus::Image* foodApple;
    Gdiplus::Image* foodBanana;
    Gdiplus::Image* foodCookies;
    Gdiplus::Image* foodPizza;
    Gdiplus::Image* foodCarrot;
    Gdiplus::Image* foodSushi;

    // Brincadeiras
    Gdiplus::Image* soccerBall;
    Gdiplus::Image* basketBall; // assets/basketball.png
    Gdiplus::Image* kite; // assets/pipa.png

public:
    OverlayRenderer();
    ~OverlayRenderer();

    bool loadAssets();
    void renderPet(HWND hwnd, const PetEngine& pet);
};
