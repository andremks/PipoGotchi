// src/OverlayRenderer.cpp

#include "OverlayRenderer.hpp"
#include "resources.h"
#include "PetEngine.h"

#include <windows.h>
#include <gdiplus.h>
#include <objidl.h>     // IStream, CreateStreamOnHGlobal
#include <algorithm>
#include <cmath>

#pragma comment(lib, "gdiplus.lib")

using namespace Gdiplus;

// ================================
// CONTROLE DE ANIMAÇÃO DO Zzz
// ================================
static float zzzOffsetY = 0.0f;
static DWORD lastZzzTick = 0;
static int zzzFrame = 0; // 0 = "zZz..", 1 = "ZzZ.."

// ================================
// CONTROLE DE ANIMAÇÃO DO PULO
// ================================
static DWORD lastJumpAnimTick = 0;
static float jumpSquashEffect = 0.0f; // efeito de "agachar" antes do pulo

// =====================================================
// HELPERS DE LOAD
// =====================================================

static void TryLoadImage(Image*& slot, const wchar_t* path) {
    if (slot) { delete slot; slot = nullptr; }

    slot = new Image(path);
    if (!(slot && slot->GetLastStatus() == Ok)) {
        delete slot;
        slot = nullptr;
    }
}

static void TryLoadPngOrJpg(Image*& slot, const wchar_t* baseNoExt) {
    wchar_t path[260];

    wsprintfW(path, L"%s.png", baseNoExt);
    TryLoadImage(slot, path);
    if (slot) return;

    wsprintfW(path, L"%s.jpg", baseNoExt);
    TryLoadImage(slot, path);
    if (slot) return;

    wsprintfW(path, L"%s.jpeg", baseNoExt);
    TryLoadImage(slot, path);
}

static Image* LoadImageFromRCDATA(int resId) {
    HMODULE hMod = GetModuleHandleW(nullptr);
    HRSRC hRes = FindResourceW(hMod, MAKEINTRESOURCEW(resId), RT_RCDATA);
    if (!hRes) return nullptr;

    DWORD size = SizeofResource(hMod, hRes);
    if (!size) return nullptr;

    HGLOBAL hData = LoadResource(hMod, hRes);
    if (!hData) return nullptr;

    void* pData = LockResource(hData);
    if (!pData) return nullptr;

    // Copia para memória móvel (CreateStreamOnHGlobal precisa disso)
    HGLOBAL hCopy = GlobalAlloc(GMEM_MOVEABLE, size);
    if (!hCopy) return nullptr;

    void* pCopy = GlobalLock(hCopy);
    if (!pCopy) { GlobalFree(hCopy); return nullptr; }

    memcpy(pCopy, pData, size);
    GlobalUnlock(hCopy);

    IStream* stream = nullptr;
    if (CreateStreamOnHGlobal(hCopy, TRUE, &stream) != S_OK) { // TRUE => stream libera hCopy
        GlobalFree(hCopy);
        return nullptr;
    }

    Image* img = new Image(stream);
    stream->Release();

    if (!(img && img->GetLastStatus() == Ok)) {
        delete img;
        return nullptr;
    }
    return img;
}

static void TryLoadRCDATA(Image*& slot, int resId) {
    if (slot) { delete slot; slot = nullptr; }
    slot = LoadImageFromRCDATA(resId);
}

static Image* PickFoodImage(
    const PetEngine& pet,
    Image* apple, Image* banana, Image* cookies,
    Image* pizza, Image* carrot, Image* sushi
) {
    if (pet.eatingEmoji == L"🍎") return apple;
    if (pet.eatingEmoji == L"🍌") return banana;
    if (pet.eatingEmoji == L"🍪") return cookies;
    if (pet.eatingEmoji == L"🍕") return pizza;
    if (pet.eatingEmoji == L"🥕") return carrot;
    if (pet.eatingEmoji == L"🍣") return sushi;
    return nullptr;
}

// =====================================================
// CTOR/DTOR
// =====================================================

OverlayRenderer::OverlayRenderer()
    : spriteWhite(nullptr),
      spriteBlue(nullptr),
      spriteGray(nullptr),
      foodApple(nullptr),
      foodBanana(nullptr),
      foodCookies(nullptr),
      foodPizza(nullptr),
      foodCarrot(nullptr),
      foodSushi(nullptr),
      soccerBall(nullptr),
      basketBall(nullptr),
      kite(nullptr) {}

OverlayRenderer::~OverlayRenderer() {
    if (spriteWhite) delete spriteWhite;
    if (spriteBlue) delete spriteBlue;
    if (spriteGray) delete spriteGray;

    if (foodApple) delete foodApple;
    if (foodBanana) delete foodBanana;
    if (foodCookies) delete foodCookies;
    if (foodPizza) delete foodPizza;
    if (foodCarrot) delete foodCarrot;
    if (foodSushi) delete foodSushi;

    if (soccerBall) delete soccerBall;
    if (basketBall) delete basketBall;
    if (kite) delete kite;
}

// =====================================================
// LOAD ASSETS
// =====================================================

bool OverlayRenderer::loadAssets() {
    // Sprites
    TryLoadRCDATA(spriteWhite, IDR_SPRITE);
    bool okWhite = (spriteWhite && spriteWhite->GetLastStatus() == Ok);

    TryLoadRCDATA(spriteBlue, IDR_SPRITE_AZUL);
    TryLoadRCDATA(spriteGray, IDR_SPRITE_CINZA);

    // Foods
    TryLoadRCDATA(foodApple, IDR_APPLE);
    TryLoadRCDATA(foodBanana, IDR_BANANA);
    TryLoadRCDATA(foodCookies, IDR_COOKIES);
    TryLoadRCDATA(foodPizza, IDR_PIZZA);
    TryLoadRCDATA(foodCarrot, IDR_CARROT);
    TryLoadRCDATA(foodSushi, IDR_SUSHI);

    // Brincadeiras
    TryLoadRCDATA(soccerBall, IDR_SOCCER_BALL);
    TryLoadRCDATA(basketBall, IDR_BASKETBALL);
    TryLoadRCDATA(kite, IDR_PIPA);

    return okWhite;
}

// =====================================================
// RENDER
// =====================================================

void OverlayRenderer::renderPet(HWND hwnd, const PetEngine& pet) {
    Image* activeSheet = spriteWhite;
    if (pet.model == PetModel::Azul && spriteBlue) activeSheet = spriteBlue;
    if (pet.model == PetModel::Cinza && spriteGray) activeSheet = spriteGray;
    if (!activeSheet) return;

    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    BITMAPINFO bmi{};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = 42;
    bmi.bmiHeader.biHeight = -42; // top-down
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    HBITMAP hBitmap = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, &bits, NULL, 0);
    HGDIOBJ oldBmp = SelectObject(hdcMem, hBitmap);

    Graphics g(hdcMem);
    g.SetInterpolationMode(InterpolationModeNearestNeighbor);
    g.Clear(Color(0, 0, 0, 0));

    // ================================
    // FRAME REAL (spritesheet 24x24)
    // ================================
    int frameReal = 0;
    float verticalOffset = 0.0f;
    float scaleY = 1.0f;

    // Respiração no sono
    float breathScaleY = 1.0f;
    float breathVerticalOffset = 0.0f;

    DWORD currentTime = GetTickCount();

    if (pet.currentState == PetState::SLEEP) {
        float breathWave = std::sin(pet.sleepBreathPhase);
        breathWave *= pet.sleepBreathIntensity;
        breathScaleY = 1.0f + (breathWave * 0.03f);
        breathVerticalOffset = breathWave * 0.5f;
        frameReal = 30; // frame fixo do sono na sheet
    } else {
        switch (pet.currentState) {
        case PetState::IDLE:
            frameReal = pet.currentFrame % 2;
            break;
        case PetState::WALK:
            frameReal = 3 + (pet.currentFrame % 7);
            break;
        case PetState::JUMPING:
            frameReal = 17 + (pet.currentFrame % 4);
            if (pet.currentFrame < 2) scaleY = 0.85f + (pet.currentFrame * 0.05f);
            else scaleY = 1.1f - ((pet.currentFrame - 2) * 0.05f);
            verticalOffset = -std::sin(pet.currentFrame * 0.3f) * 2.0f;
            break;
        case PetState::FALLING:
            frameReal = 21 + (pet.currentFrame % 4);
            if (pet.currentFrame < 2) scaleY = 1.0f + (pet.currentFrame * 0.03f);
            else scaleY = 0.9f + ((pet.currentFrame - 2) * 0.05f);
            verticalOffset = pet.currentFrame * 0.5f;
            break;
        case PetState::FREE_FALL:
            frameReal = 21;
            scaleY = 1.0f + (pet.currentFrame * 0.02f);
            verticalOffset = pet.currentFrame * 1.0f;
            break;
        default:
            frameReal = 0;
            break;
        }
    }

    int srcX = frameReal * 24;

    // vento na queda rápida
    if (pet.currentState == PetState::FALLING && pet.velY > 5.0f) {
        SolidBrush windBrush(Color(80, 255, 255, 255));
        for (int i = 0; i < 3; i++) {
            float windX = 5.0f + (i * 8.0f);
            float windY = 20.0f + (i * 5.0f);
            float windSize = 3.0f + (i * 1.0f);

            if (pet.moveDirection == 1) {
                g.FillEllipse(&windBrush, -windX, windY, windSize, windSize);
            } else {
                g.FillEllipse(&windBrush, 42.0f + windX - windSize, windY, windSize, windSize);
            }
        }
    }

    // agachadinho antes do pulo (quando mouse está perto e ainda no chão)
    if (pet.wasMouseInRange && pet.velY == 0 && !pet.jump.isJumping) {
        if (currentTime - lastJumpAnimTick > 100) {
            jumpSquashEffect = std::sin(currentTime * 0.02f) * 0.05f;
            lastJumpAnimTick = currentTime;
        } else {
            jumpSquashEffect = 0.0f;
        }
        scaleY *= (1.0f - jumpSquashEffect);
    }

    // ================================
    // DESENHAR SPRITE + ESPELHAMENTO
    // ================================
    GraphicsState spriteState = g.Save();

    float renderY = verticalOffset + breathVerticalOffset;

    // respiração no sono (escala Y)
    if (pet.currentState == PetState::SLEEP && breathScaleY != 1.0f) {
        float cY = 42.0f / 2.0f;
        g.TranslateTransform(0, cY);
        g.ScaleTransform(1.0f, breathScaleY);
        g.TranslateTransform(0, -cY);
    }

    // squash/stretch do pulo/queda
    if (scaleY != 1.0f) {
        float cY = 42.0f / 2.0f;
        g.TranslateTransform(0, cY);
        g.ScaleTransform(1.0f, scaleY);
        g.TranslateTransform(0, -cY);
    }

    // espelhar quando andando para a esquerda
    if (pet.moveDirection == -1) {
        g.TranslateTransform(42.0f, 0.0f);
        g.ScaleTransform(-1.0f, 1.0f);
    }

    g.DrawImage(
        activeSheet,
        Rect(0, (int)renderY, 42, 42),
        srcX, 0, 24, 24,
        UnitPixel
    );
    g.Restore(spriteState);

    // ================================
    // BRINCAR — SOCCER
    // ================================
    if (pet.isPlayingBall && pet.ballUntil > pet.ballStart && soccerBall) {
        float duration = (float)(pet.ballUntil - pet.ballStart);
        float t = (float)(currentTime - pet.ballStart) / duration;
        t = std::clamp(t, 0.0f, 1.0f);

        const int ballSize = 12;
        float baseX = 14.0f;
        float baseY = 24.0f;

        float stepPhase = 0.0f;
        if (pet.currentState == PetState::WALK) {
            stepPhase = (float)(pet.currentFrame % 7) / 7.0f;
        }

        float kick = std::sin(stepPhase * 6.28318f) * 1.2f;
        float bounce = std::fabs(std::sin((float)currentTime * 0.012f)) * 1.0f;
        float drift = (pet.moveDirection >= 0 ? 1.0f : -1.0f) * (t * 6.0f);

        float spins = 3.0f;
        float angle = 360.0f * (t * spins);

        int alpha = 255;
        if (t > 0.80f) {
            float ft = (t - 0.80f) / 0.20f;
            alpha = (int)(255.0f * (1.0f - ft));
            if (alpha < 0) alpha = 0;
        }

        GraphicsState ballState = g.Save();
        float cx = baseX + drift + kick + (ballSize / 2.0f);
        float cy = baseY + bounce + (ballSize / 2.0f);
        g.TranslateTransform(cx, cy);
        g.RotateTransform(angle);
        g.TranslateTransform(-cx, -cy);

        ImageAttributes ia;
        ColorMatrix cm = {
            1,0,0,0,0,
            0,1,0,0,0,
            0,0,1,0,0,
            0,0,0,(REAL)(alpha / 255.0f),0,
            0,0,0,0,1
        };
        ia.SetColorMatrix(&cm);

        Rect dest((int)(baseX + drift + kick), (int)(baseY + bounce), ballSize, ballSize);
        g.DrawImage(
            soccerBall,
            dest,
            0, 0,
            (INT)soccerBall->GetWidth(),
            (INT)soccerBall->GetHeight(),
            UnitPixel,
            &ia
        );
        g.Restore(ballState);
    }

    // ================================
    // BRINCAR — BASKETBALL
    // ================================
    if (pet.isPlayingBasketball && pet.basketUntil > pet.basketStart && basketBall) {
        float duration = (float)(pet.basketUntil - pet.basketStart);
        float t = (float)(currentTime - pet.basketStart) / duration;
        t = std::clamp(t, 0.0f, 1.0f);

        const int ballSize = 12;
        float baseX = 14.0f;
        float baseY = 24.0f;

        float stepPhase = 0.0f;
        if (pet.currentState == PetState::WALK) {
            stepPhase = (float)(pet.currentFrame % 7) / 7.0f;
        }

        float bounce = std::fabs(std::sin(stepPhase * 6.28318f)) * 6.0f;
        float sway = std::sin(stepPhase * 6.28318f) * 0.6f;

        int alpha = 255;
        if (t > 0.85f) {
            float ft = (t - 0.85f) / 0.15f;
            alpha = (int)(255.0f * (1.0f - ft));
            if (alpha < 0) alpha = 0;
        }

        ImageAttributes ia;
        ColorMatrix cm = {
            1,0,0,0,0,
            0,1,0,0,0,
            0,0,1,0,0,
            0,0,0,(REAL)(alpha / 255.0f),0,
            0,0,0,0,1
        };
        ia.SetColorMatrix(&cm);

        Rect dest((int)(baseX + sway), (int)(baseY - bounce), ballSize, ballSize);
        g.DrawImage(
            basketBall,
            dest,
            0, 0,
            (INT)basketBall->GetWidth(),
            (INT)basketBall->GetHeight(),
            UnitPixel,
            &ia
        );
    }

    // ================================
    // BRINCAR — PIPA
    // ================================
    if (pet.isPlayingKite && pet.kiteUntil > pet.kiteStart && kite) {
        float duration = (float)(pet.kiteUntil - pet.kiteStart);
        float t = (float)(currentTime - pet.kiteStart) / duration;
        t = std::clamp(t, 0.0f, 1.0f);

        const int kiteW = 14;
        const int kiteH = 14;

        float baseX = 14.0f;
        float yGround = 28.0f;
        float yTop = 0.0f;

        float stepPhase = 0.0f;
        if (pet.currentState == PetState::WALK) {
            stepPhase = (float)(pet.currentFrame % 7) / 7.0f;
        }

        float behind = -(6.0f + t * 6.0f);
        float swayX = std::sin((float)currentTime * 0.010f + stepPhase * 6.28318f) * 1.8f;
        float swayY = std::cos((float)currentTime * 0.012f + stepPhase * 6.28318f) * 1.2f;

        float y = yTop;
        if (t < 0.25f) {
            float u = t / 0.25f;
            float ease = 1.0f - (1.0f - u) * (1.0f - u); // easeOutQuad
            y = yGround + (yTop - yGround) * ease;
        } else {
            y = yTop;
        }

        int alpha = 255;
        if (t > 0.85f) {
            float ft = (t - 0.85f) / 0.15f;
            alpha = (int)(255.0f * (1.0f - ft));
            if (alpha < 0) alpha = 0;
        }

        float angle = std::sin((float)currentTime * 0.010f) * 10.0f;

        GraphicsState kiteState = g.Save();

        // Espelhar junto com o pet (igual a sprite)
        if (pet.moveDirection == -1) {
            g.TranslateTransform(42.0f, 0.0f);
            g.ScaleTransform(-1.0f, 1.0f);
        }

        // "Fio"
        Pen linePen(Color((int)(alpha * 0.85f), 0, 0, 0), 1.0f);
        PointF hand(24.0f, 26.0f);
        PointF kitePt(baseX + behind + swayX + (kiteW / 2.0f), y + swayY + (kiteH / 2.0f));
        g.DrawLine(&linePen, hand, kitePt);

        // Pipa com rotação e alpha
        float cx = baseX + behind + swayX + (kiteW / 2.0f);
        float cy = y + swayY + (kiteH / 2.0f);
        g.TranslateTransform(cx, cy);
        g.RotateTransform(angle);
        g.TranslateTransform(-cx, -cy);

        ImageAttributes ia;
        ColorMatrix cm = {
            1,0,0,0,0,
            0,1,0,0,0,
            0,0,1,0,0,
            0,0,0,(REAL)(alpha / 255.0f),0,
            0,0,0,0,1
        };
        ia.SetColorMatrix(&cm);

        Rect dest((int)(baseX + behind + swayX), (int)(y + swayY), kiteW, kiteH);
        g.DrawImage(
            kite,
            dest,
            0, 0,
            (INT)kite->GetWidth(),
            (INT)kite->GetHeight(),
            UnitPixel,
            &ia
        );

        g.Restore(kiteState);
    }

    // ================================
    // COMER — tenta IMG, senão emoji
    // ================================
    if (pet.isEating && !pet.eatingEmoji.empty()) {
        DWORD dur = (pet.eatingUntil > pet.eatingStart) ? (pet.eatingUntil - pet.eatingStart) : 1;
        float t = (float)(currentTime - pet.eatingStart) / (float)dur;
        t = std::clamp(t, 0.0f, 1.0f);

        float chew = std::fabs(std::sin(t * 6.28318f * 2.0f));
        float jitterX = std::sin(currentTime * 0.020f) * 0.6f;
        float jitterY = std::cos(currentTime * 0.018f) * 0.4f;

        float popIn = std::sin(std::min(1.0f - t, 1.0f) * 1.57079f);
        float scale = 1.10f + popIn * 0.35f - chew * 0.12f;

        int alpha = 255;
        if (t > 0.85f) {
            float ft = (t - 0.85f) / 0.15f;
            alpha = (int)(255.0f * (1.0f - ft));
            if (alpha < 0) alpha = 0;
        }

        float baseX = 16.0f;
        float baseY = 20.0f;

        Image* foodImg = PickFoodImage(pet, foodApple, foodBanana, foodCookies, foodPizza, foodCarrot, foodSushi);

        if (foodImg) {
            GraphicsState eatState = g.Save();
            float cx = baseX;
            float cy = baseY;
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(scale, scale);
            g.TranslateTransform(-cx, -cy);

            ImageAttributes ia;
            ColorMatrix cm = {
                1,0,0,0,0,
                0,1,0,0,0,
                0,0,1,0,0,
                0,0,0,(REAL)(alpha / 255.0f),0,
                0,0,0,0,1
            };
            ia.SetColorMatrix(&cm);

            Rect dest((int)(baseX + jitterX), (int)(baseY + jitterY), 14, 14);
            g.DrawImage(
                foodImg,
                dest,
                0, 0,
                (INT)foodImg->GetWidth(),
                (INT)foodImg->GetHeight(),
                UnitPixel,
                &ia
            );

            g.Restore(eatState);
        } else {
            FontFamily ff(L"Segoe UI Emoji");
            Font foodFont(&ff, 16, FontStyleRegular, UnitPixel);

            SolidBrush shadow(Color((int)(alpha * 0.55f), 0, 0, 0));
            SolidBrush text(Color(alpha, 255, 255, 255));

            GraphicsState eatState = g.Save();
            float cx = baseX;
            float cy = baseY;
            g.TranslateTransform(cx, cy);
            g.ScaleTransform(scale, scale);
            g.TranslateTransform(-cx, -cy);

            g.DrawString(pet.eatingEmoji.c_str(), -1, &foodFont,
                         PointF(baseX + 1.0f + jitterX, baseY + 1.0f + jitterY), &shadow);
            g.DrawString(pet.eatingEmoji.c_str(), -1, &foodFont,
                         PointF(baseX + jitterX, baseY + jitterY), &text);

            g.Restore(eatState);
        }
    }

    // ================================
    // Zzz...
    // ================================
    if (pet.currentState == PetState::SLEEP) {
        DWORD now = GetTickCount();
        if (now - lastZzzTick > 40) {
            lastZzzTick = now;
            zzzOffsetY -= 0.3f;
            if (zzzOffsetY < -6.0f) zzzOffsetY = 0.0f;

            if (now % 800 < 400) zzzFrame = 0;
            else zzzFrame = 1;

            const wchar_t* zzzText = (zzzFrame == 0) ? L"zZz.." : L"ZzZ..";
            FontFamily fontFamily(L"Arial");
            Font font(&fontFamily, 10, FontStyleBold, UnitPixel);

            float zzzYOffset = 3.0f + zzzOffsetY + (breathVerticalOffset * 2.0f);

            SolidBrush shadow(Color(120, 0, 0, 0));
            SolidBrush text(Color(220, 255, 255, 255));
            g.DrawString(zzzText, -1, &font, PointF(7.0f, 4.0f + zzzYOffset), &shadow);
            g.DrawString(zzzText, -1, &font, PointF(6.0f, 3.0f + zzzYOffset), &text);
        }
    } else {
        zzzOffsetY = 0.0f;
    }

    // ================================
    // Carinho (♥) + partículas
    // ================================
    if (pet.isPetting) {
        FontFamily fontFamily(L"Arial");
        Font font(&fontFamily, 12, FontStyleBold, UnitPixel);
        SolidBrush shadow(Color(140, 0, 0, 0));
        SolidBrush text(Color(240, 255, 105, 180));
        g.DrawString(L"♥", -1, &font, PointF(27.0f, 4.0f), &shadow);
        g.DrawString(L"♥", -1, &font, PointF(26.0f, 3.0f), &text);
    }

    if (!pet.hearts.empty()) {
        FontFamily ff(L"Arial");
        Font heartFont(&ff, 12, FontStyleBold, UnitPixel);

        const float FADE_START_Y = -5.0f;
        const float FADE_END_Y = 0.0f;

        for (const auto& p : pet.hearts) {
            float hx = p.x;
            float hy = p.y;

            float tt = 1.0f;
            if (hy <= FADE_START_Y) tt = 0.0f;
            else if (hy < FADE_END_Y) tt = (hy - FADE_START_Y) / (FADE_END_Y - FADE_START_Y);

            int aHeart = (int)(230.0f * tt);
            int aShadow = (int)(120.0f * tt);
            aHeart = std::clamp(aHeart, 0, 230);
            aShadow = std::clamp(aShadow, 0, 120);

            SolidBrush heartBrush(Color(aHeart, 255, 80, 140));
            SolidBrush heartShadow(Color(aShadow, 0, 0, 0));
            const wchar_t* heart = L"♥";

            g.DrawString(heart, -1, &heartFont, PointF(hx + 1.0f, hy + 1.0f), &heartShadow);
            g.DrawString(heart, -1, &heartFont, PointF(hx, hy), &heartBrush);
        }
    }

    // ================================
    // UPDATE LAYERED WINDOW
    // ================================
    POINT ptSrc = { 0, 0 };
    POINT ptDst = { pet.x, pet.y };
    SIZE size = { 42, 42 };

    BLENDFUNCTION bf{};
    bf.BlendOp = AC_SRC_OVER;
    bf.SourceConstantAlpha = 255;
    bf.AlphaFormat = AC_SRC_ALPHA;

    UpdateLayeredWindow(
        hwnd,
        hdcScreen,
        &ptDst,
        &size,
        hdcMem,
        &ptSrc,
        0,
        &bf,
        ULW_ALPHA
    );

    // ================================
    // LIMPEZA
    // ================================
    SelectObject(hdcMem, oldBmp);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}
