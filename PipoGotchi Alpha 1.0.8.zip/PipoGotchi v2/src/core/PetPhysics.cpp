#include "../include/PetEngine.h"
#include <cmath>

namespace PetPhysics {

    void PetPhysics::applyJump(PetEngine& pet, float power, float direction) {
    // Verifica se pode pular (no chão e não pulando já)
    if (pet.velY == 0 && !pet.jump.isJumping) {
        pet.velY = -power; // Negativo = para cima
        pet.x += (int)(direction * 10); // Pequeno impulso lateral
        
        // Atualiza estado
        pet.currentState = PetState::JUMPING;
        pet.jump.isJumping = true;
        pet.jump.jumpStartTime = GetTickCount();
    }
}


    void applyGravity(PetEngine& pet, int groundY) {
        if (pet.y < groundY) {
            pet.velY += 0.8f;
            pet.y += (int)pet.velY;
            
            if (pet.y >= groundY) {
                pet.y = groundY;
                pet.velY = 0;
            }
        } else {
            pet.y = groundY;
            pet.velY = 0;
        }
    }
}