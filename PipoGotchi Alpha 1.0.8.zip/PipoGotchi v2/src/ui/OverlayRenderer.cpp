#include "OverlayRenderer.hpp"
#include <windows.h>
#include <gdiplus.h>
#include "../include/PetEngine.h"
#include <cmath>

#pragma comment(lib, "gdiplus.lib")

// ================================
// CONTROLE DE ANIMAÇÃO DO Zzz
// ================================
static float zzzOffsetY = 0.0f;
static DWORD lastZzzTick = 0;
static int zzzFrame = 0; // 0 = "Zz", 1 = "Zzz"

// ================================
// CONTROLE DE ANIMAÇÃO DO PULO
// ================================
static DWORD lastJumpAnimTick = 0;
static float jumpSquashEffect = 0.0f; // Efeito de "agachamento" antes do pulo

OverlayRenderer::OverlayRenderer()
    : spriteSheet(nullptr) {}

OverlayRenderer::~OverlayRenderer()
{
    if (spriteSheet)
        delete spriteSheet;
}

bool OverlayRenderer::loadAssets()
{
    using namespace Gdiplus;
    spriteSheet = new Image(L"assets/sprite.png");
    return (spriteSheet && spriteSheet->GetLastStatus() == Ok);
}

void OverlayRenderer::renderPet(HWND hwnd, const PetEngine &pet)
{
    using namespace Gdiplus;

    if (!spriteSheet)
        return;

    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    BITMAPINFO bmi = {};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = 42;
    bmi.bmiHeader.biHeight = -42;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void *bits = nullptr;
    HBITMAP hBitmap = CreateDIBSection(
        hdcScreen, &bmi, DIB_RGB_COLORS, &bits, NULL, 0);

    HGDIOBJ oldBmp = SelectObject(hdcMem, hBitmap);

    Graphics g(hdcMem);
    g.SetInterpolationMode(InterpolationModeNearestNeighbor);
    g.Clear(Color(0, 0, 0, 0));

    // ================================
    // FRAME REAL (COM OS NOVOS ESTADOS DE PULO)
    // ================================
    int frameReal = 0;
    float verticalOffset = 0.0f; // Para efeitos de animação
    float scaleY = 1.0f;         // Para efeito de "agachamento" ou "esticamento"

    switch (pet.currentState)
    {
    case PetState::SLEEP:
        frameReal = 30;
        break;

    case PetState::IDLE:
        frameReal = pet.currentFrame % 2; // Frames 0-1
        break;

    case PetState::WALK:
        frameReal = 3 + (pet.currentFrame % 7); // Frames 2-8
        break;

    case PetState::JUMPING:
        // Frames 17-20 para subida
        frameReal = 17 + (pet.currentFrame % 4);

    case PetState::FREE_FALL:
        frameReal = 21;  // Frame específico para queda livre
        // Efeitos visuais extras para queda
        scaleY = 1.0f + (pet.currentFrame * 0.02f);  // Leve esticamento
        verticalOffset = pet.currentFrame * 1.0f;    // Movimento rápido para baixo
        break;

        // Efeito visual durante a subida
        if (pet.currentFrame < 2)
        {
            // Início do pulo: leve "agachamento"
            scaleY = 0.85f + (pet.currentFrame * 0.05f);
        }
        else
        {
            // Meio do pulo: leve "esticamento"
            scaleY = 1.1f - ((pet.currentFrame - 2) * 0.05f);
        }

        // Efeito de flutuação
        verticalOffset = -sin(pet.currentFrame * 0.3f) * 2.0f;
        break;

    case PetState::FALLING:
        // Frames 21-24 para descida
        frameReal = 21 + (pet.currentFrame % 4);

        // Efeito visual durante a queda
        if (pet.currentFrame < 2)
        {
            // Topo da queda: mais "redondo"
            scaleY = 1.0f + (pet.currentFrame * 0.03f);
        }
        else
        {
            // Quase aterrissando: se prepara para impacto
            scaleY = 0.9f + ((pet.currentFrame - 2) * 0.05f);
        }

        // Efeito de queda mais rápida
        verticalOffset = pet.currentFrame * 0.5f;
        break;

    default:
        frameReal = 0; // Fallback
        break;
    }

    int srcX = frameReal * 24;

    // Na seção de renderização, após desenhar o sprite:
    if (pet.currentState == PetState::FALLING && pet.velY > 5.0f)
    {
        // Efeito de "vento" durante queda rápida
        SolidBrush windBrush(Color(80, 255, 255, 255));

        // Partículas de vento atrás do pet
        for (int i = 0; i < 3; i++)
        {
            float windX = 5.0f + (i * 8.0f);
            float windY = 20.0f + (i * 5.0f);
            float windSize = 3.0f + (i * 1.0f);

            if (pet.moveDirection == 1) // Virado para direita
                g.FillEllipse(&windBrush, -windX, windY, windSize, windSize);
            else // Virado para esquerda
                g.FillEllipse(&windBrush, 42.0f + windX - windSize, windY, windSize, windSize);
        }
    }

    // ================================
    // EFEITO DE "AGACHAMENTO" ANTES DO PULO
    // ================================
    DWORD currentTime = GetTickCount();

    // Verificar se o cursor acabou de entrar no raio (preparação para pulo)
    if (pet.wasMouseInRange && pet.velY == 0 && !pet.jump.isJumping)
    {
        // Pequeno efeito de antecipação
        if (currentTime - lastJumpAnimTick > 100)
        {
            jumpSquashEffect = sin(currentTime * 0.02f) * 0.05f;
            lastJumpAnimTick = currentTime;
        }
        scaleY *= (1.0f - jumpSquashEffect);
    }
    else
    {
        jumpSquashEffect = 0.0f;
    }

    // ================================
    // SPRITE (COM ESPELHAMENTO E EFEITOS)
    // ================================
    GraphicsState spriteState = g.Save();

    // Posicionamento base
    float renderX = 0.0f;
    float renderY = verticalOffset;

    // Aplicar escala para efeitos (centrado)
    if (scaleY != 1.0f)
    {
        float scaleCenterY = 42.0f / 2.0f;
        g.TranslateTransform(0, scaleCenterY);
        g.ScaleTransform(1.0f, scaleY);
        g.TranslateTransform(0, -scaleCenterY);
    }

    // Espelhamento se estiver virado para esquerda
    if (pet.moveDirection == -1)
    {
        g.ScaleTransform(-1.0f, 1.0f);
        g.TranslateTransform(-42.0f, 0.0f);
    }

    // Desenhar o sprite
    g.DrawImage(
        spriteSheet,
        Rect((int)renderX, (int)renderY, 42, 42),
        srcX, 0, 24, 24,
        UnitPixel);

    g.Restore(spriteState);

    // ================================
    // ANIMAÇÃO DO Zzz...
    // ================================
    if (pet.currentState == PetState::SLEEP)
    {
        DWORD now = GetTickCount();

        // sobe lentamente
        if (now - lastZzzTick > 40)
        {
            lastZzzTick = now;
            zzzOffsetY -= 0.3f;

            if (zzzOffsetY < -6.0f)
                zzzOffsetY = 0.0f;
        }

        // alterna texto
        if (now % 800 < 400)
            zzzFrame = 0;
        else
            zzzFrame = 1;

        const wchar_t *zzzText = (zzzFrame == 0) ? L"zZz.." : L"ZzZ..";

        FontFamily fontFamily(L"Arial");
        Font font(&fontFamily, 10, FontStyleBold, UnitPixel);

        // sombra
        SolidBrush shadow(Color(120, 0, 0, 0));
        g.DrawString(
            zzzText, -1, &font,
            PointF(7.0f, 4.0f + zzzOffsetY),
            &shadow);

        // texto
        SolidBrush text(Color(220, 255, 255, 255));
        g.DrawString(
            zzzText, -1, &font,
            PointF(6.0f, 3.0f + zzzOffsetY),
            &text);
    }
    else
    {
        // reset ao acordar
        zzzOffsetY = 0.0f;
    }

    // ================================
    // UPDATE LAYERED WINDOW
    // ================================
    POINT ptSrc = {0, 0};
    POINT ptDst = {pet.x, pet.y};
    SIZE size = {42, 42};

    BLENDFUNCTION bf = {};
    bf.BlendOp = AC_SRC_OVER;
    bf.SourceConstantAlpha = 255;
    bf.AlphaFormat = AC_SRC_ALPHA;

    UpdateLayeredWindow(
        hwnd,
        hdcScreen,
        &ptDst,
        &size,
        hdcMem,
        &ptSrc,
        0,
        &bf,
        ULW_ALPHA);

    // ================================
    // LIMPEZA
    // ================================
    SelectObject(hdcMem, oldBmp);
    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}