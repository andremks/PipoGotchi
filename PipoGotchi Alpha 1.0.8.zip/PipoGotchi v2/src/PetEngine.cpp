#include "../include/PetEngine.h"
#include "../include/SystemCore.h"
#include <cstdlib>
#include <cmath>

// =====================================================
// FUNÇÕES AUXILIARES PARA PULO
// =====================================================

float PetEngine::calculateJumpPower(int distX, int distY)
{
    // Distância euclidiana do cursor
    float distance = sqrt(distX * distX + distY * distY);

    // Normalizar para 0-1 (cursor mais longe = pulo mais alto)
    float normalized = distance / 120.0f;

    // Limitar entre 0.3 e 1.0
    if (normalized < 0.3f)
        normalized = 0.3f;
    if (normalized > 1.0f)
        normalized = 1.0f;

    // Calcular altura máxima para este pulo
    float jumpHeight = normalized * jump.MAX_JUMP_HEIGHT;

    // Limitar altura máxima absoluta
    if (jumpHeight > MAX_JUMP_HEIGHT)
    {
        jumpHeight = MAX_JUMP_HEIGHT;
    }

    return jumpHeight;
}

void PetEngine::triggerJump(int distX, int distY)
{
    DWORD now = GetTickCount();

    // Cooldown para evitar spam
    if (now - lastJumpTime < JUMP_COOLDOWN)
        return;

    // Só pula se estiver no chão
    if (velY != 0)
        return;

    jump.jumpPower = calculateJumpPower(distX, distY);

    // Dar um pequeno empurrão horizontal (oposto ao cursor)
    jump.horizontalKick = (distX > 0) ? -2.0f : 2.0f;

    jump.isJumping = true;
    jump.jumpStartTime = now;
    velY = -jump.jumpPower * 0.1f;

    // Mudar estado
    if (currentState != PetState::SLEEP)
    {
        currentState = PetState::JUMPING;
        currentFrame = 0;
        frameCounter = 0;
    }

    lastJumpTime = now;
}

// =====================================================
// FUNÇÃO PRINCIPAL UPDATE
// =====================================================

void PetEngine::Update(RECT workArea, POINT mousePos, RECT activeWindowRect, bool isWindowValid)
{
    // =====================================================
    // PASSO 1 — DETECTAR MOVIMENTO DO MOUSE
    // =====================================================
    DWORD currentTime = GetTickCount();

    if (mousePos.x != lastMousePos.x || mousePos.y != lastMousePos.y)
    {
        lastMousePos = mousePos;
        lastMouseMoveTime = currentTime;

        // Acorda se estiver dormindo
        if (currentState == PetState::SLEEP)
        {
            currentState = PetState::IDLE;
            currentFrame = 2;
            frameCounter = 0;
        }
    }

    // =====================================================
    // PASSO 2 — ENTRAR EM MODO DORMIR
    // =====================================================
    const DWORD SLEEP_DELAY = 16000; // 16 segundos

    if (!isDragging && (currentTime - lastMouseMoveTime > SLEEP_DELAY))
    {
        if (currentState != PetState::SLEEP)
        {
            currentState = PetState::SLEEP;
            currentFrame = 2;
            frameCounter = 0;
        }
    }

    // Enquanto dorme, não executa o resto do Update
    if (currentState == PetState::SLEEP)
    {
        velY = 0;
        return;
    }

    const int RENDER_W = 40;

    // =====================================================
    // 1. MODO ARRASTAR
    // =====================================================
    if (isDragging)
    {
        x = mousePos.x - dragOffset.x;
        y = mousePos.y - dragOffset.y;
        velY = 0;
        return;
    }

    // =====================================================
    // 2. COMPORTAMENTO E DETECÇÃO DE PULO
    // =====================================================

    // Calcular distância do cursor
    int distX = mousePos.x - (x + (RENDER_W / 2));
    int distY = mousePos.y - (y + (RENDER_W / 2));
    float distanceToCursor = sqrt(distX * distX + distY * distY);
    bool mousePerto = (distanceToCursor <= 120);

    // Detectar se cursor acabou de entrar no raio
    bool cursorEntrouAgora = false;
    if (mousePerto && !wasMouseInRange)
    {
        cursorEntrouAgora = true;
        wasMouseInRange = true;
    }
    else if (!mousePerto)
    {
        wasMouseInRange = false;
    }

    PetState estadoAnterior = currentState;

    // Comportamento baseado na proximidade do cursor
    if (mousePerto)
    {
        // Cursor dentro do raio - comportamento reativo
        if (cursorEntrouAgora && !isDragging)
        {
            // Cursor acabou de entrar - ativar pulo
            DWORD jumpTime = GetTickCount();

            // Verificar condições para pular:
            if (!isDragging && velY == 0 &&
                currentState != PetState::SLEEP &&
                (jumpTime - lastJumpTime) > JUMP_COOLDOWN)
            {
                // Calcular força do pulo baseada na distância
                float normalizedDistance = distanceToCursor / 120.0f;

                // Garantir pulo mínimo (30%) e máximo (100%)
                if (normalizedDistance < 0.3f)
                    normalizedDistance = 0.3f;
                if (normalizedDistance > 1.0f)
                    normalizedDistance = 1.0f;

                // Altura do pulo proporcional à distância
                jump.jumpPower = normalizedDistance * jump.MAX_JUMP_HEIGHT;

                // Direção do pulo (oposta ao cursor para parecer "assustado")
                jump.horizontalKick = (distX > 0) ? -1.5f : 1.5f;

                // Força extra se o cursor vier de cima
                if (distY < -30)
                {
                    jump.jumpPower *= 1.2f; // Pulo 20% mais alto
                }

                // Ativar estado de pulo
                jump.isJumping = true;
                jump.jumpStartTime = jumpTime;
                velY = -jump.jumpPower * 0.15f;

                // Mudar estado para JUMPING
                currentState = PetState::JUMPING;
                currentFrame = 0;
                frameCounter = 0;

                // Registrar tempo do pulo
                lastJumpTime = jumpTime;

                // Resetar timer de comportamento
                behaviorTimer = 0;
            }
        }

        // Depois do pulo (ou se não pulou), comportamento normal
        if (!jump.isJumping)
        {
            if (abs(distX) > 15 && velY == 0)
            {
                // Seguir cursor suavemente
                currentState = PetState::WALK;
                moveDirection = (distX > 0) ? 1 : -1;
                speed = 3.5f + (abs(distX) / 120.0f) * 1.0f;
            }
            else
            {
                // Ficar parado olhando para o cursor
                currentState = PetState::IDLE;
                if (abs(distX) > 5)
                {
                    moveDirection = (distX > 0) ? 1 : -1;
                }
            }
        }
    }
    else
    {
        // Cursor fora do raio - comportamento autônomo
        wasMouseInRange = false;

        behaviorTimer++;

        // Comportamento aleatório a cada ~2 segundos
        if (behaviorTimer > 120 && !jump.isJumping)
        {
            behaviorTimer = 0;

            // 60% chance de ficar parado, 40% de andar
            if (rand() % 100 < 60)
            {
                currentState = PetState::IDLE;
            }
            else
            {
                currentState = PetState::WALK;
                moveDirection = (rand() % 3 == 0) ? -moveDirection : moveDirection;
            }

            // Velocidade aleatória
            speed = 2.0f + (rand() % 100) / 100.0f;
        }
    }

    // Reset de animação ao trocar de estado (exceto durante pulo)
    if (currentState != estadoAnterior && !jump.isJumping)
    {
        currentFrame = 0;
        frameCounter = 0;
    }

    // Comportamento especial durante o pulo - VERSÃO SIMPLIFICADA
    if (jump.isJumping)
    {
        DWORD now = GetTickCount();
        float elapsed = now - jump.jumpStartTime;

        // Fase de subida (primeiros 40%)
        if (elapsed < jump.JUMP_DURATION * 0.4f)
        {
            // Aplicar impulso horizontal
            x += (int)jump.horizontalKick;
            currentState = PetState::JUMPING;
        }
        // Fase de pico/transição (40-60%)
        else if (elapsed < jump.JUMP_DURATION * 0.6f)
        {
            // Transição para queda
            if (currentState == PetState::JUMPING)
            {
                currentState = PetState::FALLING;
                currentFrame = 0;
                frameCounter = 0;
            }
        }
        // Fase de queda (60-100%)
        else
        {
            // Reduzir impulso horizontal durante a queda
            jump.horizontalKick *= 0.95f;

            // Forçar término do pulo se estiver caindo muito rápido
            if (velY > TERMINAL_VELOCITY * 0.8f)
            {
                jump.isJumping = false;
            }
        }
    }

    // =====================================================
    // 3. FÍSICA E CHÃO
    // =====================================================

    // 3.1 — Determinar o chão base
    int screenBottom = GetSystemMetrics(SM_CYSCREEN);
    int groundY;

    // Se estiver em modo tela cheia (F11/Jogos), o chão é o limite zero da tela
    if (SystemCore::IsFullscreenActive())
    {
        groundY = screenBottom - RENDER_W + 4;
    }
    else
    {
        // Caso contrário, usa o limite da WorkArea (em cima da barra de tarefas)
        groundY = workArea.bottom - RENDER_W + 4;
    }

    isOnWindow = false;

    // 3.2 — Verificação de colisão com a Janela Ativa (APENAS SE ACIMA DO CHÃO BASE)
    if (isWindowValid)
    {
        int petRight = x + RENDER_W;
        int petBottom = y + RENDER_W;

        bool overlapX = petRight > activeWindowRect.left &&
                        x < activeWindowRect.right;

        bool closeBelow = petBottom >= activeWindowRect.top &&
                          petBottom <= activeWindowRect.top + 40;

        int windowGroundY = activeWindowRect.top - (RENDER_W - 5);

        // ⚠️ SÓ considera a janela se ela estiver ACIMA da taskbar
        if (overlapX && closeBelow && windowGroundY < groundY)
        {
            groundY = windowGroundY;
            isOnWindow = true;
        }
    }

    // 3.3 — FÍSICA COM LIMITES
    if (y < groundY || jump.isJumping)
    {
        // Aplicar gravidade
        velY += GRAVITY;

        // Limitar velocidade máxima de queda
        if (velY > TERMINAL_VELOCITY)
        {
            velY = TERMINAL_VELOCITY;
        }

        // Limitar altura máxima (não subir mais que MAX_JUMP_HEIGHT pixels)
        if (jump.isJumping && velY < 0)
        {
            int alturaAtual = groundY - y;
            if (alturaAtual > MAX_JUMP_HEIGHT)
            {
                velY = 0; // Parar de subir
                jump.isJumping = false;
                currentState = PetState::FALLING;
            }
        }

        // Aplicar movimento
        y += (int)velY;

        // Verificar aterrissagem
        if (y >= groundY)
        {
            y = groundY;
            velY = 0;

            // Finalizar pulo se estiver no chão
            if (jump.isJumping || currentState == PetState::JUMPING || currentState == PetState::FALLING)
            {
                jump.isJumping = false;
                currentState = PetState::IDLE;
                currentFrame = 0;
                frameCounter = 0;
            }
        }
    }
    else if (y > groundY)
    {
        // Correção se ficar abaixo do chão
        y = groundY;
        velY = 0;
    }
    else
    {
        // No chão
        velY = 0;
    }

    // 3.4 — Movimentação Lateral (Caminhar)
    if (currentState == PetState::WALK && velY == 0)
    {
        x += (int)(moveDirection * speed);
    }

    // 3.5 — Limites Laterais (Teleporte de borda a borda)
    if (x > workArea.right)
        x = workArea.left - RENDER_W;
    else if (x < workArea.left - RENDER_W)
        x = workArea.right;



    // =====================================================
    // DETECTAR QUEDA LIVRE
    // =====================================================
    if (velY > TERMINAL_VELOCITY * 0.7f && !isOnWindow && !jump.isJumping) {
        // Queda rápida e não está em uma janela nem pulando
        currentState = PetState::FREE_FALL;
        currentFrame = 0;  // Resetar animação
        frameCounter = 0;
    } 
    else if (currentState == PetState::FREE_FALL && velY < TERMINAL_VELOCITY * 0.3f) {
        // Sai da queda livre quando desacelera
        currentState = PetState::IDLE;
        currentFrame = 0;
        frameCounter = 0;
    }

    // =====================================================
    // 4. ANIMAÇÃO
    // =====================================================
    frameCounter++;

    int framesCount = 0;
    int animSpeed = 0;

    // TRAVA DE SEGURANÇA: Se estiver dormindo, força o frame 1 e ignora o resto
    if (currentState == PetState::SLEEP)
    {
        currentFrame = 2; // Força explicitamente o frame dos olhos fechados
        frameCounter = 0;
        return; // Sai da função IMEDIATAMENTE para nada mudar o currentFrame
    }

    if (currentState == PetState::IDLE)
    {
        framesCount = 2; // Frames 0-1
        animSpeed = 12;
        currentFrame = std::min(currentFrame, 1); // Garantir frame válido
    }
    else if (currentState == PetState::WALK)
    {
        framesCount = 7; // Frames 2-8
        animSpeed = 2;
        currentFrame = std::min(currentFrame, 6); // Garantir frame válido
    }
    else if (currentState == PetState::JUMPING)
    {
        framesCount = 4; // Frames 17-20 (subida)
        animSpeed = 6;   // Animação mais lenta no ar
        // Offset: começar no frame 17
        currentFrame = std::min(currentFrame, 3); // 0-3 → 17-20
    }
    else if (currentState == PetState::FALLING)
    {
        framesCount = 4; // Frames 21-24 (descida)
        animSpeed = 8;   // Animação mais rápida na queda
        // Offset: começar no frame 21
        currentFrame = std::min(currentFrame, 3); // 0-3 → 21-24
    }

    // Só troca o frame se o contador atingir a velocidade e NÃO estiver dormindo
    if (animSpeed > 0 && frameCounter >= animSpeed)
    {
        frameCounter = 0;
        currentFrame = (currentFrame + 1) % framesCount;
    }

    static bool wasOnWindow = false;
    bool justFellFromWindow = false;
}