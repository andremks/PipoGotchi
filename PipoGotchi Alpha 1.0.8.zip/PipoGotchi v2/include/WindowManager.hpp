#pragma once
#include <windows.h>

class WindowManager {
public:
    static HWND createWindow(HINSTANCE hInstance, WNDPROC wndProc);
    static void setAlwaysOnTop(HWND hwnd);
    static RECT getWorkArea();
};