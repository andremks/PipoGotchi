#pragma once
#include <windows.h>

namespace Gdiplus {
    class Image;
}

class PetEngine;

class OverlayRenderer {
private:
    Gdiplus::Image* spriteSheet;  // Nome mais descritivo
    
public:
    OverlayRenderer();
    ~OverlayRenderer();
    
    // Carrega sprite.png
    bool loadAssets();
    
    // Renderiza o pet usando a sprite sheet
    void renderPet(HWND hwnd, const PetEngine& pet);
    
    // Getter opcional
    Gdiplus::Image* getSpriteSheet() const { return spriteSheet; }
};