#include "../include/SystemCore.h"

HWND SystemCore::CreatePetWindow(HINSTANCE hInstance, WNDPROC wndProc)
{
    const wchar_t CLASS_NAME[] = L"PipoGotchiClass";
    WNDCLASS wc = {};
    wc.lpfnWndProc = wndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;

    RegisterClass(&wc);

    return CreateWindowEx(
        WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        CLASS_NAME, L"PipoGotchi",
        WS_POPUP | WS_VISIBLE, // Certifique-se de que WS_VISIBLE está aqui
        100, 100, 32, 32,      // MUDOU PARA 32x32
        NULL, NULL, hInstance, NULL);
}

// ... após a função CreatePetWindow

RECT SystemCore::GetWorkArea()
{
    RECT workArea;
    // Tenta pegar a área útil (descontando a taskbar)
    SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);

    // Verifica se a Taskbar está oculta ou se há algo em tela cheia
    HWND hTaskbar = FindWindow(L"Shell_TrayWnd", NULL);
    if (hTaskbar)
    {
        if (!IsWindowVisible(hTaskbar))
        {
            // Se a taskbar está invisível (F11/Jogos), o chão é o limite do monitor
            workArea.bottom = GetSystemMetrics(SM_CYSCREEN);
            workArea.right = GetSystemMetrics(SM_CXSCREEN);
        }
    }

    return workArea;
}

bool SystemCore::IsFullscreenActive() {
    HWND hwnd = GetForegroundWindow(); // Pega a janela que o usuário está usando
    if (!hwnd) return false;

    RECT windowRect;
    GetWindowRect(hwnd, &windowRect);

    // Pega a resolução total do monitor onde a janela está
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Se a janela ativa ocupa a tela inteira, ignoramos a WorkArea
    return (windowRect.left <= 0 && windowRect.top <= 0 &&
            windowRect.right >= screenWidth && windowRect.bottom >= screenHeight);
}