#include <windows.h>
#include <gdiplus.h>
#include "../include/SystemCore.h"
#include "../include/PetEngine.h"
#include "../include/OverlayRenderer.hpp"

#pragma comment(lib, "gdiplus.lib")

#define ID_SAIR 1001

using namespace Gdiplus;

// ===============================
// VARIÁVEIS GLOBAIS
// ===============================
PetEngine pipo;
OverlayRenderer renderer;

// ===============================
// WINDOW PROCEDURE
// ===============================
LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CREATE:
    {
        if (!renderer.loadAssets()) {
            MessageBox(hwnd, L"Erro ao carregar imagens em /assets", L"PipoGotchi", MB_ICONERROR);
        }
        // O Timer de 33ms (~30 FPS) cuidará das atualizações
        SetTimer(hwnd, 1, 33, NULL);
    }
        return 0;

    case WM_TIMER:
    {
        // 1. ATUALIZAÇÃO DA ÁREA DE TRABALHO (DETECTA F11/TASKBAR)
        // Chamamos GetWorkArea a cada ciclo para detectar mudanças dinâmicas
        RECT workArea = SystemCore::GetWorkArea();

        POINT mouse;
        GetCursorPos(&mouse);

        // 2. LÓGICA DE DETECÇÃO DE JANELAS (PARA O PET SUBIR NELAS)
        POINT probe;
        probe.x = pipo.x + 16;
        probe.y = pipo.y + 42;

        HWND target = WindowFromPoint(probe);
        RECT activeRect{};
        bool validWindow = false;

        if (target && target != hwnd && target != GetShellWindow() && IsWindowVisible(target))
        {
            WINDOWPLACEMENT wp{sizeof(WINDOWPLACEMENT)};
            GetWindowPlacement(target, &wp);
            if (wp.showCmd == SW_SHOWNORMAL)
            {
                if (GetWindowRect(target, &activeRect))
                {
                    if (activeRect.top > workArea.top + 40)
                        validWindow = true;
                }
            }
        }

        // 3. ATUALIZA O MOTOR (AQUI ELE CHECA SystemCore::IsFullscreenActive INTERNAMENTE)
        pipo.Update(workArea, mouse, activeRect, validWindow);
        
        // 4. RENDERIZA E MOVE A JANELA PARA A NOVA POSIÇÃO
        renderer.renderPet(hwnd, pipo);

        // Atualiza a posição real da janela conforme o X e Y calculados no motor
        SetWindowPos(hwnd, HWND_TOPMOST, pipo.x, pipo.y, 0, 0, 
                     SWP_NOSIZE | SWP_NOACTIVATE);
    }
        return 0;

    case WM_LBUTTONDOWN:
    {
        SetCapture(hwnd);
        pipo.isDragging = true;
        POINT mouse;
        GetCursorPos(&mouse);
        pipo.dragOffset.x = mouse.x - pipo.x;
        pipo.dragOffset.y = mouse.y - pipo.y;
    }
        return 0;

    case WM_LBUTTONUP:
        ReleaseCapture();
        pipo.isDragging = false;
        return 0;

    case WM_CONTEXTMENU:
    {
        HMENU hMenu = CreatePopupMenu();
        AppendMenu(hMenu, MF_STRING, ID_SAIR, L"Sair");
        TrackPopupMenu(hMenu, TPM_RIGHTBUTTON, LOWORD(lParam), HIWORD(lParam), 0, hwnd, NULL);
        DestroyMenu(hMenu);
    }
        return 0;

    case WM_COMMAND:
        if (LOWORD(wParam) == ID_SAIR)
            DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        KillTimer(hwnd, 1);
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, msg, wParam, lParam);
}

// ===============================
// WINMAIN
// ===============================
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int)
{
    SetProcessDPIAware();

    GdiplusStartupInput gsi;
    ULONG_PTR gToken;
    GdiplusStartup(&gToken, &gsi, NULL);

    // Cria a janela usando sua SystemCore
    HWND hwnd = SystemCore::CreatePetWindow(hInst, WindowProc);

    // Posição inicial
    RECT wa = SystemCore::GetWorkArea();
    pipo.x = wa.right - 150;
    pipo.y = wa.bottom - 40;

    ShowWindow(hwnd, SW_SHOW);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    GdiplusShutdown(gToken);
    return 0;
}