#ifndef PETENGINE_H
#define PETENGINE_H

#include <windows.h>
#include "PetState.hpp"

struct JumpPhysics {
    float jumpPower = 0;
    float horizontalKick = 0;
    bool isJumping = false;
    DWORD jumpStartTime = 0;
    const float MAX_JUMP_HEIGHT = 80.0f;
    const float JUMP_DURATION = 400; // ms
};

class PetEngine
{
public:
    int x = 100, y = 100;
    float speed = 2.0f;
    float velY = 0;
    int moveDirection = 1;

    PetState currentState = PetState::IDLE;

    int currentFrame = 0;
    int frameCounter = 0;
    bool isOnWindow = false;
    int behaviorTimer = 0;
    bool isDragging = false;
    POINT dragOffset = {0, 0};
    DWORD lastMouseMoveTime = 0;
    POINT lastMousePos = {0, 0};

    JumpPhysics jump;
    bool wasMouseInRange = false;
    DWORD lastJumpTime = 0;
    
    // CONSTANTES DE FÍSICA
    const int JUMP_COOLDOWN = 800;
    const float GRAVITY = 2.5f;
    const float MAX_JUMP_HEIGHT = 30.0f;
    const float TERMINAL_VELOCITY = 12.0f;
    
    float calculateJumpPower(int distX, int distY);
    float sleepBreathPhase = 0.0f;
    float sleepBreathIntensity = 0.0f;
    DWORD lastBreathUpdate = 0; 
    void triggerJump(int distX, int distY);

    void Update(RECT workArea, POINT mousePos, RECT activeWindowRect, bool isWindowValid);
};

#endif