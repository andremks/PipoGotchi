#pragma once

#define IDR_SPRITE           101
#define IDR_SPRITE_AZUL      102
#define IDR_SPRITE_CINZA     103

#define IDR_SOCCER_BALL      201
#define IDR_BASKETBALL       202
#define IDR_PIPA             203
#define IDR_VARAPESCAR 204
#define IDR_PEIXE      205

#define IDR_APPLE            301
#define IDR_BANANA           302
#define IDR_COOKIES          303
#define IDR_PIZZA            304
#define IDR_CARROT           305
#define IDR_SUSHI            306
#define IDI_APPICON 1
