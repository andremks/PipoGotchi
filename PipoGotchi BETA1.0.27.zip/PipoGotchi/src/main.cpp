// src/main.cpp

#include <windows.h>
#include <gdiplus.h>

#include "SystemCore.h"
#include "PetEngine.h"
#include "OverlayRenderer.hpp"

#pragma comment(lib, "gdiplus.lib")

#define ID_SAIR 1001

#define ID_MODEL_BRANCO 2001
#define ID_MODEL_AZUL   2002
#define ID_MODEL_CINZA  2003

// Alimentos
#define ID_FOOD_APPLE   3001
#define ID_FOOD_BANANA  3002
#define ID_FOOD_COOKIE  3003
#define ID_FOOD_PIZZA   3004
#define ID_FOOD_CARROT  3005
#define ID_FOOD_SUSHI   3006

// Brincadeiras
#define ID_PLAY_BALL        4001
#define ID_PLAY_BASKETBALL  4002
#define ID_PLAY_KITE        4003
#define ID_PLAY_FISHING 4004

using namespace Gdiplus;

// ===============================
// VARIÁVEIS GLOBAIS
// ===============================
PetEngine pipo;
OverlayRenderer renderer;

static POINT GetPetCenterPoint() {
    // Renderer desenha em 42x42; usamos o centro aproximado.
    POINT c;
    c.x = pipo.x + 21;
    c.y = pipo.y + 21;
    return c;
}

// ===============================
// WINDOW PROCEDURE
// ===============================
LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {

    case WM_CREATE: {
        if (!renderer.loadAssets()) {
            MessageBox(hwnd, L"Erro ao carregar imagens em /assets (ou recursos).",
                       L"PipoGotchi", MB_ICONERROR);
        }
        SetTimer(hwnd, 1, 33, NULL);
        return 0;
    }

    case WM_TIMER: {
        POINT mouse{};
        GetCursorPos(&mouse);

        // Multi-monitor:
        // - Se estiver arrastando, o "mundo" deve ser o monitor do mouse (fica natural ao soltar).
        // - Senão, usa o monitor onde o pet está (centro do sprite).
        POINT refPt = pipo.isDragging ? mouse : GetPetCenterPoint();
        RECT workArea = SystemCore::GetWorkAreaFromPoint(refPt);

        // Detectar janela “abaixo” do pet (para andar em cima).
        // IMPORTANTE: probe usa coordenadas globais.
        POINT probe{};
        probe.x = pipo.x + 16;
        probe.y = pipo.y + 42;

        HWND target = WindowFromPoint(probe);
        RECT activeRect{};
        bool validWindow = false;

        if (target && target != hwnd && target != GetShellWindow() && IsWindowVisible(target)) {
            WINDOWPLACEMENT wp{ sizeof(WINDOWPLACEMENT) };
            if (GetWindowPlacement(target, &wp)) {
                // Mantém sua regra original (só SHOWNORMAL).
                if (wp.showCmd == SW_SHOWNORMAL) {
                    if (GetWindowRect(target, &activeRect)) {
                        if (activeRect.top > workArea.top + 40) {
                            validWindow = true;
                        }
                    }
                }
            }
        }

        pipo.Update(workArea, mouse, activeRect, validWindow);
        renderer.renderPet(hwnd, pipo);

        SetWindowPos(hwnd, HWND_TOPMOST, pipo.x, pipo.y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
        return 0;
    }

    case WM_LBUTTONDOWN: {
        SetCapture(hwnd);
        pipo.isDragging = true;

        POINT mouse{};
        GetCursorPos(&mouse);
        pipo.dragOffset.x = mouse.x - pipo.x;
        pipo.dragOffset.y = mouse.y - pipo.y;
        return 0;
    }

    case WM_LBUTTONUP: {
        ReleaseCapture();
        pipo.isDragging = false;
        return 0;
    }

    case WM_LBUTTONDBLCLK: {
        pipo.StartPetting(2000);
        return 0;
    }

    case WM_CONTEXTMENU: {
        HMENU hMenu = CreatePopupMenu();

        // ---- Submenu Modelos
        HMENU hModelos = CreatePopupMenu();
        AppendMenu(hModelos, MF_STRING, ID_MODEL_BRANCO, L"⚪ Chibi Totoro (Branco)");
        AppendMenu(hModelos, MF_STRING, ID_MODEL_AZUL,   L"🔵 Chu Totoro (Azul)");
        AppendMenu(hModelos, MF_STRING, ID_MODEL_CINZA,  L"⚫ Ō Totoro (Cinza)");

        UINT checked = ID_MODEL_BRANCO;
        if (pipo.model == PetModel::Azul)  checked = ID_MODEL_AZUL;
        if (pipo.model == PetModel::Cinza) checked = ID_MODEL_CINZA;
        CheckMenuRadioItem(hModelos, ID_MODEL_BRANCO, ID_MODEL_CINZA, checked, MF_BYCOMMAND);
        AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hModelos, L"🐾 Modelos");

        // ---- Submenu Alimentos
        HMENU hAlimentos = CreatePopupMenu();
        AppendMenu(hAlimentos, MF_STRING, ID_FOOD_APPLE,  L"🍎 Maçã");
        AppendMenu(hAlimentos, MF_STRING, ID_FOOD_BANANA, L"🍌 Banana");
        AppendMenu(hAlimentos, MF_STRING, ID_FOOD_COOKIE, L"🍪 Cookie");
        AppendMenu(hAlimentos, MF_STRING, ID_FOOD_PIZZA,  L"🍕 Pizza");
        AppendMenu(hAlimentos, MF_STRING, ID_FOOD_CARROT, L"🥕 Cenoura");
        AppendMenu(hAlimentos, MF_STRING, ID_FOOD_SUSHI,  L"🍣 Sushi");
        AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hAlimentos, L"🍽 Alimentos");

        // ---- Submenu Brincar
        HMENU hBrincar = CreatePopupMenu();
        AppendMenu(hBrincar, MF_STRING, ID_PLAY_BALL,       L"⚽ Jogar bola");
        AppendMenu(hBrincar, MF_STRING, ID_PLAY_BASKETBALL, L"🏀 Basketball");
        AppendMenu(hBrincar, MF_STRING, ID_PLAY_FISHING, L"🎣 Pescaria");
        AppendMenu(hBrincar, MF_STRING, ID_PLAY_KITE,       L"🪁 Pipa");
        AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hBrincar, L"🎮 Brincar");

        AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
        AppendMenu(hMenu, MF_STRING, ID_SAIR, L"✕ Sair");

        TrackPopupMenu(
            hMenu,
            TPM_RIGHTBUTTON,
            LOWORD(lParam), HIWORD(lParam),
            0, hwnd, NULL
        );

        DestroyMenu(hBrincar);
        DestroyMenu(hAlimentos);
        DestroyMenu(hModelos);
        DestroyMenu(hMenu);
        return 0;
    }

    case WM_COMMAND: {
        switch (LOWORD(wParam)) {
        case ID_MODEL_BRANCO: pipo.model = PetModel::Branco; return 0;
        case ID_MODEL_AZUL:   pipo.model = PetModel::Azul;   return 0;
        case ID_MODEL_CINZA:  pipo.model = PetModel::Cinza;  return 0;

        // Alimentos (emoji exibido no pet via renderer)
        case ID_FOOD_APPLE:  pipo.StartEating(L"🍎", 1500); return 0;
        case ID_FOOD_BANANA: pipo.StartEating(L"🍌", 1500); return 0;
        case ID_FOOD_COOKIE: pipo.StartEating(L"🍪", 1500); return 0;
        case ID_FOOD_PIZZA:  pipo.StartEating(L"🍕", 1500); return 0;
        case ID_FOOD_CARROT: pipo.StartEating(L"🥕", 1500); return 0;
        case ID_FOOD_SUSHI:  pipo.StartEating(L"🍣", 1500); return 0;

        // Brincadeiras
        case ID_PLAY_BALL:       pipo.StartPlayingBall(3200);       return 0;
        case ID_PLAY_BASKETBALL: pipo.StartPlayingBasketball(3200); return 0;
        case ID_PLAY_KITE:       pipo.StartPlayingKite(4200);       return 0;
        case ID_PLAY_FISHING:    pipo.StartPlayingFishing(3600);    return 0;

        case ID_SAIR:
            DestroyWindow(hwnd);
            return 0;
        }
        return 0;
    }

    case WM_DESTROY:
        KillTimer(hwnd, 1);
        PostQuitMessage(0);
        return 0;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

// ===============================
// WINMAIN
// ===============================
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int) {
    SetProcessDPIAware();

    GdiplusStartupInput gsi{};
    ULONG_PTR gToken{};
    GdiplusStartup(&gToken, &gsi, NULL);

    HWND hwnd = SystemCore::CreatePetWindow(hInst, WindowProc);

    // Spawn no centro do work area do monitor do mouse (se houver múltiplos monitores, fica natural).
    POINT mouse{};
    GetCursorPos(&mouse);
    RECT wa = SystemCore::GetWorkAreaFromPoint(mouse);

    const int RENDER_W = 40;
    int centerX = wa.left + (wa.right - wa.left) / 2;
    pipo.x = centerX - (RENDER_W / 2);
    pipo.y = wa.bottom - RENDER_W + 4;

    ShowWindow(hwnd, SW_SHOW);

    MSG msg{};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    GdiplusShutdown(gToken);
    return 0;
}
